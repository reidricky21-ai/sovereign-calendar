from pathlib import Path
from html.parser import HTMLParser
import re,json,subprocess
root=Path(__file__).parent
class Parser(HTMLParser):
 def __init__(self):super().__init__();self.ids=[];self.links=[];self.targets=[]
 def handle_starttag(self,tag,attrs):
  a=dict(attrs)
  if a.get('id'):self.ids.append(a['id'])
  if tag in ('script','img','link','iframe'):
   src=a.get('src') or a.get('href')
   if src and not src.startswith(('https:','http:','data:','#')):self.links.append(src)
  if a.get('data-v8-go'):self.targets.append(a['data-v8-go'])
p=Parser(); html=(root/'index.html').read_text();p.feed(html)
assert len(p.ids)==len(set(p.ids)),[x for x in set(p.ids) if p.ids.count(x)>1]
missing=[x for x in p.links if not (root/x.split('?')[0]).exists()]
assert not missing,missing
panes=re.findall(r'id="([a-z]+)Pane"',html)
assert len(panes)==14,(len(panes),panes)
assert all(t in panes for t in p.targets),[t for t in p.targets if t not in panes]
css=(root/'v11-visual.css').read_text()
cssfiles=re.findall(r'url\([\'\"]?([^\)\'\"]+)',css)
assert all((root/x.replace('./','')).exists() for x in cssfiles),cssfiles
jsfiles=list(root.rglob('*.js'))
for path in jsfiles:
 cp=subprocess.run(['node','--check',str(path)],capture_output=True,text=True)
 assert cp.returncode==0,(path,cp.stderr)
print(json.dumps({'unique_ids':len(p.ids),'panes':len(panes),'cross_navigation_links':len(p.targets),'script_and_link_assets':len(p.links),'css_image_assets':len(cssfiles),'script_files_syntax_checked':len(jsfiles)},indent=2))
