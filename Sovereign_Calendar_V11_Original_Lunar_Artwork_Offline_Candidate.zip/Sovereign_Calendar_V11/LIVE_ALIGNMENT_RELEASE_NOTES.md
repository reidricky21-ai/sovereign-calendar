# Sovereign Calendar V11 — Live Alignment Explorer candidate

Based on Visual Readability Offline V11; not production-approved.

## Added
- Select a UTC date and minute in the illustrated Alignment Atlas, or choose Now.
- Displays the precise Sovereign and Praxis operators, Praxis day number, next Sovereign and Praxis transition in UTC, and next mathematical month boundary.
- Updates the approved/unresolved interpretive pairing from the actual selected timestamp, not a generic sample.
- Tap a monthly journey entry to inspect its exact opening instant in the Atlas.
- Open the selected mathematical month from the Atlas, or navigate to Praxis teaching.
- Preserves the original Sovereign Engine, personal commencement state, journaling, artwork, favorites, and 72-node explorer.
- Distinct service-worker cache version for later test installation.

## Automated checks
- Sovereign and Praxis cycle tests, monthly navigation, simulated backup round trip, and static release gate passed.

## Not yet checked
- Browser/Android PWA click-through of all new controls, installed offline behavior, source-origin storage persistence, service-worker upgrade, screenshot and accessibility acceptance. Do not replace production until these pass.

## Time and interpretation policy
- UTC input is explicit and never silently converted to device local time.
- Interpretations are philosophical notes, not astronomical observations or empirical predictions.
- Mathematical month uses exactly 29.53 days and is not an observed lunar month.
