# V11 narrowly scoped Praxis source integration

Added source-labeled sutra excerpts to the existing eight Praxis operator lessons and their I Ching trigram reference. No changes to Sovereign or Praxis calendar calculations; no new physical exercises.

Sources: Yoga Sutras.docx, Book I, Sutras 2, 3, 4, 5, 6, 7; I Ching Asanas.docx, Part I operator–trigram key. These are authored Akinraic interpretations, not claims about historical translations, physiology, or confirmed physics. Sutra 2 and Sutra 6 are intentionally associated with two operators each.

I Ching Asanas.docx marks King Wen entries 17–32 and 49–64 pending. We do not manufacture missing entries or use the images' distorted printed text as verified definitions.

No change to gallery assets, user data schema, journal, commencement settings, or original research instruments. Must pass browser and Android checks prior to release.
