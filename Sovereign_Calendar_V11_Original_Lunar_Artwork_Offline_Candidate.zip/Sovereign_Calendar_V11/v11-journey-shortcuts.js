/* V11 guided path: non-invasive progressive disclosure on the five primary screens. */
(()=>{'use strict';
const routes=[
 {pane:'livingPane',anchor:'.sovereign-home-v11',steps:[['Understand the alignment','#v11HomePairTitle'],['Begin today’s Praxis','#v11HomePraxis'],['Explore the cycle','summary:Eight days']]},
 {pane:'dualPane',anchor:'#v11CalendarFeature',steps:[['Read the alignment','#v11AlignmentAtlas'],['View the month journey','#v11CalJourney'],['Open detailed calendar','#v11CalOpen']]},
 {pane:'praxisatlasPane',anchor:'.v11-praxis-ref',steps:[['Read today’s teaching','#v11PxTitle'],['Write a reflection','#v11PxOpenJournal'],['Choose my beginning','#v11PxCommence']]},
 {pane:'languagePane',anchor:'.v11-codex',steps:[['Learn the eight operators','#v11CodexOperatorGrid'],['Explore a word','#v11LexicalConcordance'],['Explore grammar','summary:Grammar validity']]},
 {pane:'galleryPane',anchor:'.gallery-spotlight',steps:[['Browse artwork','#v11GalleryGrid'],['Choose a collection','#v11Filters'],['View featured artwork','.gallery-spotlight']]}
];
function destination(pane,sel){if(sel.startsWith('summary:'))return [...pane.querySelectorAll('summary')].find(e=>e.textContent.includes(sel.slice(8)))||null;return pane.querySelector(sel)}
function reveal(el){let parent=el?.closest('details');while(parent){parent.open=true;parent=parent.parentElement?.closest('details')} }
function build(){routes.forEach(({pane:pid,anchor,steps})=>{const pane=document.getElementById(pid);if(!pane||pane.querySelector('.v11-pathways'))return;const hero=pane.querySelector(anchor);if(!hero)return;const nav=document.createElement('nav');nav.className='v11-pathways';nav.setAttribute('aria-label','Suggested steps on this screen');const label=document.createElement('span');label.className='v11-pathways-label';label.textContent='WHERE TO NEXT';nav.append(label);for(const [caption,sel] of steps){if(!destination(pane,sel))continue;const button=document.createElement('button');button.type='button';button.className='v11-pathway';button.textContent=caption;button.addEventListener('click',()=>{const target=destination(pane,sel);if(!target)return;reveal(target);target.scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth',block:'start'});if(target.matches('button')&&target.id==='v11PxOpenJournal')target.click();});nav.append(button)}hero.insertAdjacentElement('afterend',nav)})}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',build,{once:true});else build();
})();
