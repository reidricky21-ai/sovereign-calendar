# V11 Visual acceptance refinement — offline checkpoint

- Tested at 360 and 390 px in an isolated, in-memory Chromium harness (not a deployable browser origin).
- Main five dock buttons responded; no uncaught JS errors and no horizontal overflow in the test harness.
- Removed the duplicate legacy introduction from primary Codex pane and improved mobile spacing.
- Gallery manifest loaded when supplied directly into harness; normal-origin thumbnail display remains unverified.
- PWA install, service worker, persisted browser storage, backup export/import and Android acceptance remain pending.
- This ZIP is not cleared for Netlify deployment.
