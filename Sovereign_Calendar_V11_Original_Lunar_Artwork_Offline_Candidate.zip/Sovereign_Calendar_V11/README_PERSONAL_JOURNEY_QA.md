# V11 Personal Praxis Navigation QA — Offline checkpoint

## Changes
- Personal commencement remains under Praxis → My Journey.
- The illustrated chamber's detailed-settings control now opens the existing Calendar settings and scrolls/focuses its commencement selector.
- After a save attempt, the chamber refreshes its saved-start label from the underlying localStorage value, not solely an informational message.
- Original Sovereign/Praxis calendar code and storage key remain unchanged.
- Cache, manifest and update labels updated for this QA checkpoint.

## Verified offline
- JavaScript parsing, asset references, duplicate IDs and packaging.
- Sovereign/Praxis arithmetic regression.
- Month navigation simulated test.
- Five-category sample backup/restore test.

## Not yet verified
- Actual mobile-browser navigation and save/reload on a persistent HTTPS origin.
- Android PWA updates and retained user data.

**Do not deploy to Netlify yet.**
