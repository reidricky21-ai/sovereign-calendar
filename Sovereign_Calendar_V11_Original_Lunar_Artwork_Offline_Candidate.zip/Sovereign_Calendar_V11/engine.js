/* Sovereign Calendar mathematical engine — version 1.0.0. No UI dependencies. */
(function(root){
 'use strict';
 const EPOCH=Date.UTC(2024,2,10,9,0,0);
 const DAY=86400000;
 const MONTH=2551392000; // exactly 29.53 * 86,400,000 milliseconds
 const YEAR=18*MONTH;
 const OPERATORS=Object.freeze([
  ['Se','Essence','✺'],['Me','Identity','◇'],['Le','Truth','△'],
  ['Da','Authority','▥'],['Ye','Purpose','↗'],['Ha','Hiddenness','◈'],
  ['Re','Resonance','◎'],['Ka','Force','✦']]);
 function mod(n,m){return ((n%m)+m)%m}
 function calculate(date){
  const ms=(date instanceof Date?date.getTime():new Date(date).getTime())-EPOCH;
  if(!Number.isFinite(ms))throw new Error('Invalid date');
  const globalMonth=Math.floor(ms/MONTH);
  const y=Math.floor(globalMonth/18)+1;
  const m=mod(globalMonth,18)+1;
  const monthStart=EPOCH+globalMonth*MONTH;
  const dayInMonth=Math.floor((ms-(monthStart-EPOCH))/DAY)+1;
  const opIndex=mod(Math.floor(ms/DAY),8);
  return {y,m,dayInMonth,op:OPERATORS[opIndex],globalMonth,elapsed:ms/DAY,monthStartUTC:monthStart, operatorIndex:opIndex};
 }
 function monthBoundary(globalMonth){return new Date(EPOCH+globalMonth*MONTH)}
 function moonPhase(date){ // mean-synodic-cycle estimate, not observed ephemeris
  const ms=(date instanceof Date?date:new Date(date)).getTime();
  const f=mod((ms-EPOCH)/DAY/29.530588853,1);
  const illum=(1-Math.cos(2*Math.PI*f))/2;
  const labels=['New Moon','Waxing crescent','First quarter','Waxing gibbous','Full Moon','Waning gibbous','Last quarter','Waning crescent'];
  return {label:labels[Math.floor((f+1/16)*8)%8],pct:Math.round(1000*illum)/10,phaseFraction:f};
 }
 const api=Object.freeze({EPOCH,DAY,MONTH,YEAR,OPERATORS,calculate,monthBoundary,moonPhase});
 root.SovereignEngine=api;
 if(typeof module==='object'&&module.exports)module.exports=api;
})(typeof globalThis==='object'?globalThis:this);
