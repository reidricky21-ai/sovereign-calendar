(()=>{'use strict';
const $=id=>document.getElementById(id);
const DAYS=29.53, PARTS=8;
// These are symbolic reading positions. They do not change the independent
// monthly Praxis order, nor are they astronomical moon phases.
const stages=[
 ['Attention','Begin with observation rather than an assumed conclusion.'],
 ['Distinction','Separate what is experienced from what is inferred.'],
 ['Inquiry','Consider the referent and the comparison without forcing agreement.'],
 ['Examination','Ask what evidence would establish or challenge an interpretation.'],
 ['Expression','Notice how purpose might become observable through action.'],
 ['Cultivation','Consider the habits and conditions that support continuing development.'],
 ['Reflection','Examine what an outcome reveals and what it does not reveal.'],
 ['Renewal','Carry forward what is useful; leave uncertainty open without penalties.']
];
function calculate(ms,x){
 if(!x || !Number.isFinite(x.start) || !Number.isFinite(x.end) || x.end<=x.start) return null;
 const elapsed=Math.max(0,Math.min(x.end-x.start,ms-x.start));
 const fraction=elapsed/(x.end-x.start);
 const index=Math.min(PARTS-1,Math.floor(fraction*PARTS));
 return {fraction,index,stage:stages[index],monthDay:elapsed/86400000+1};
}
function render(ms=Date.now()){
 const x=window.SovereignPraxisMonth?.at(ms);
 const el=$('v11McPosition'); if(!el||!x?.active)return;
 const data=calculate(ms,x);if(!data)return;
 const pct=(data.fraction*100).toFixed(1);
 el.textContent='Mathematical month '+(x.idx%18+1)+' · Day '+data.monthDay.toFixed(2)+' of '+DAYS.toFixed(2)+' · '+pct+'% elapsed';
 const meter=$('v11McMeter');meter.setAttribute('aria-valuenow',String(Math.round(data.fraction*100)));meter.setAttribute('aria-valuetext',pct+' percent of mathematical month elapsed');
 $('v11McFill').style.width=pct+'%';
 $('v11McStage').textContent='Symbolic segment '+(data.index+1)+' of 8 — '+data.stage[0];
 $('v11McGuidance').textContent=data.stage[1]+' Today’s operator comparison remains '+x.s+'–'+x.p+'. The monthly Praxis lesson does not depend on having completed an earlier segment.';
}
function init(){if(!$('v11McPosition'))return;render();document.addEventListener('visibilitychange',()=>{if(!document.hidden)render()});setInterval(()=>{if(!document.hidden)render()},60000);}
window.SovereignMonthContext={calculate,stages};
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
