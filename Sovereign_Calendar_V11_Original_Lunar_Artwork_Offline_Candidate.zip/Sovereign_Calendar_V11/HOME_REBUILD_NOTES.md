# V11 reference-based Home reconstruction

Original V10/V11 functional modules retained; new Home artwork-first layout, dynamic 24-hour Sovereign and monthly Praxis UTC pairing, countdown and month progress; original chart and gallery accessible below. Original Home elements hidden visually but retained for existing refresh handlers. Local browser rendering and UI interaction remain to be verified. Do not deploy to Netlify yet.

## Mobile Chromium audit — 2026-10-17
- Full-page rendering at 360px and 390px succeeded without horizontal overflow.
- Resolved a null-element crash in legacy celestial/civic refresh: marker detail elements absent from artwork-first Home now cause a safe early return rather than an exception.
- about:blank preview continues to report localStorage access denied; this is a security limitation of this test origin and does not verify persistence.
- Full origin-based browser navigation is blocked by this environment. Android/PWA and real-origin persistence still pending.
- Comparison: visually stronger artwork and alignment, but hero still starts after title/settings/instrument controls; additional mockup fidelity refinement pending.
