(()=>{'use strict';
// Source: Akinraic-English Prescriptive Dictionary, Part II; symbolic alternatives:
// The Combined Symbolic Dictionary, Part I. This is a literary concordance, not
// a statement of historical Egyptian readings or validated physical effects.
const lex={
Se:['Essence','S/I','ሰ','𓏋','𓇯','Emergent potential and expression of source.','Return to source; receptive stillness.'],
Me:['Identity','S/I','ሜ / መ','𓂝','𓄤','Expressed or recognized identity.','Self-reflection and examination of identity.'],
Le:['Truth','R/I','ሌ / ለ','𓏼','𓋹','Communication and verification against truth.','Discernment and inward examination.'],
Da:['Structure / Authority','R/I','ዳ / ደ','𓏏','𓂧','Ordering, establishing and organizing.','Support, grounding and structural steadiness.'],
Ye:['Purpose / Direction','D/I','የ','𓁹','𓇳','Intention expressed as direction.','Considering and aligning purpose inwardly.'],
Ha:['Hidden / Harmony','O/I','ሀ','𓏳','𓏤','Emerging potential and an opening field.','The held, unseen or inwardly gathered.'],
Re:['Resonance','O/I','ሬ / ረ','𓇋','𓇋','An expression perceived in the field.','Reception and listening to a response.'],
Ka:['Force / Sovereignty','O/I','ካ / ከ','𓎣','𓎛','Initiating agency and directed action.','The gathering and restraint of capacity.']};
const byId=id=>document.getElementById(id);
const block=byId('v11LexicalConcordance');if(!block)return;
const update=op=>{const e=lex[op];if(!e)return;
byId('v11LexicalHeading').textContent=op+' · '+e[0];
byId('v11LexicalClass').textContent=e[1]+' · class labels reproduced from the Prescriptive Dictionary';
byId('v11LexicalGeez').textContent=e[2];byId('v11LexicalPreferred').textContent=e[3];
byId('v11LexicalAlternate').textContent=e[4];
byId('v11LexicalOutward').textContent=e[5];byId('v11LexicalInward').textContent=e[6];
byId('v11LexicalConflict').hidden=e[3]===e[4];
};
block.addEventListener('click',e=>{const op=e.target.closest('[data-lex-op]')?.dataset.lexOp;if(op)update(op)});
for(const btn of document.querySelectorAll('#v11CodexOperatorGrid button'))btn.addEventListener('click',()=>update(btn.dataset.op));
update('Se');
})();
