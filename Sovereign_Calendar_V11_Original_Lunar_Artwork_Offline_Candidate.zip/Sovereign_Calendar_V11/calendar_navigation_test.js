const assert=require('node:assert/strict'), fs=require('fs'), vm=require('vm');
const eng=require('./engine.js');
const nodes=new Map();
function el(id){if(!nodes.has(id)){let listeners={};nodes.set(id,{id,textContent:'',children:[],addEventListener:(x,fn)=>(listeners[x]??=[]).push(fn),click(){for(const fn of listeners.click||[])fn()},replaceChildren(){this.children=[]},append(x){this.children.push(x)},scrollIntoView(){},listeners})}return nodes.get(id)}
['v11CalendarFeature','v11CalPeriod','v11CalCivil','v11CalTitle','v11CalLive','v11CalJourney','v11CalNote','v11CalBack','v11CalForward','v11CalToday','v11CalTimeline','v11CalOpen','v10MonthControls','v10Prev','v10Next','v10Today'].forEach(el);
let legacy=eng.calculate(new Date()).globalMonth;
for(const [id,delta] of [['v10Prev',-1],['v10Next',1]])el(id).addEventListener('click',()=>{legacy=Math.max(32,legacy+delta)});
el('v10Today').addEventListener('click',()=>{legacy=eng.calculate(new Date()).globalMonth});
const doc={getElementById: id=>nodes.get(id)||null,createElement:tag=>({tagName:tag,style:{},addEventListener(t,f){this.fn=f},set innerHTML(v){this.html=v},set className(v){this.cn=v},set type(v){this.ty=v}})};
const context={document:doc,window:{SovereignEngine:eng,SovereignPraxisMonth:{at:()=>({p:'Ye'})}},Date,console};
vm.runInNewContext(fs.readFileSync('./v11-calendar-visual.js','utf8'),context);
const start=eng.calculate(new Date()).globalMonth;
const text=()=>el('v11CalPeriod').textContent;
const month=()=>+text().match(/MONTH (\d+)/)[1];
assert.equal(el('v11CalJourney').children.length,8);
el('v11CalForward').click();assert.equal(legacy,start+1);assert.equal(month(), ((start+1)%18)+1);
el('v11CalBack').click();assert.equal(legacy,start);assert.equal(month(),(start%18)+1);
el('v11CalToday').click();assert.equal(legacy,start);
console.log('PASS: journey entries, forward/back once, restored selected month and legacy calendar synchronization.');
