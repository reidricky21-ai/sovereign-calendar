# Stage D regression and release audit

## Static preservation checks
- `engine.js`, `v10-dual.js`, `research-data.js`, explorer files preserved exactly from Stage C.
- No deletions of navigation panes or primary tab destinations.
- Existing user artworks copied without edits.

## Browser checklist (pending actual device tests)
1. Open every primary and legacy tab (especially 72-Node Explorer).
2. Validate Praxis monthly reset at exact epoch boundary and the final partial period.
3. Test UTC, Toronto, DST transition displays.
4. Test favorites, journey settings, notes, backup/export/import (on copy).
5. Open ambient gallery, prev/next, play/pause, reduced motion, close with Escape.
6. Reopen offline and verify essential app assets cached.
7. Verify installed Android PWA receives updated version without erasing storage.

## Scope
Static and syntax checks are NOT substitutes for an interactive device test.
