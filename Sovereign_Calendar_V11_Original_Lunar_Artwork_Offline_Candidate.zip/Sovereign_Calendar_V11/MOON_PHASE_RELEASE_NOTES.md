# V11 Moon Phase Daily Teacher candidate — October 21, 2026

Adds a distinct astronomical phase panel to the Daily Teacher, showing the selected civil day’s approximate phase and illuminated percentage. Uses the existing 2024–2035 astronomical_events.csv table for dated New Moon, First Quarter, Full Moon and Last Quarter events; displays up to four upcoming entries in browser-local time. Major-phase markers are not extrapolated beyond the available table.

The fixed 29.53-day mathematical Sovereign month, eight symbolic subdivisions, operator cycle, and separately resetting Praxis are not modified. Dates for the major events in CSV were supplied by an earlier app version; no new independent ephemeris verification was carried out in this update. Illumination is approximate and is derived from the existing engine.js mean-synodic phase model.

Verification: JavaScript syntax, archive, file-references and dataset bounds checks. Device/PWA persistence testing outstanding.
