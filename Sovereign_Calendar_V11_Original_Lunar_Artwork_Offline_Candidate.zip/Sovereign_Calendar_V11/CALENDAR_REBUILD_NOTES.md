# V11 Calendar illustrated reconstruction — offline preview

Added `v11-calendar-visual.css` and `v11-calendar-visual.js`, with a new accessible calendar hero in `dualPane`. The hero uses `artwork/ha-continuity.webp` (supplied asset), the actual SovereignEngine epoch for month labels and boundary timestamps, live current operator, and the first eight instructional day starts of the selected Praxis month. Dates are real calculated data, not literal mockup values.

The existing V10 month controls and all detailed per-transition rows remain authoritative and accessible below the new hero. A Praxis day can change Sovereign operator during its interval; the visual eight-entry journey depicts only the opening pairing and explicitly discloses this limitation. For months before Praxis founding, the UI shows Sovereign-only chronology.

**Not yet visually accepted:** Mobile Chromium screenshots, calendar navigation tap tests, real-origin storage and PWA upgrade. **Do not deploy to Netlify yet.** This is one screen reconstruction in the consolidated release.
