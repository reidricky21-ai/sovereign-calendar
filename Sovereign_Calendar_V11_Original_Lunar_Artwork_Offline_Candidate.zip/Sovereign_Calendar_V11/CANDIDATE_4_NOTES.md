# V11 Visual Candidate 4 — Offline presentation refinement

## Changes
- Converted the formerly prominent version/updates/backup/restore panel into a collapsed `Settings · Backups · Updates` disclosure, retaining its existing element IDs and child event targets.
- Condensed the research/instruments control and header spacing so the original-art Home hero is closer to the first viewport.
- Refined narrow-screen hero typography and minimum height.
- Unified version labels across application, updater, PWA manifest, service-worker cache, and release-gate script.
- Kept calendar engines, journaling, gallery, source artwork, and 72-Node Explorer unchanged.

## Verified in this environment
- Release gate: 14 JavaScript files; 166 unique IDs; 19 HTML file references; 46 service-worker references; no errors.
- Structural QA: 14 original panes; all referenced resources available.
- Mathematical QA: 1,200 consecutive operator days, 250 month transitions, 68 Praxis month resets.
- Isolated five-category backup and restore round-trip passes.

## Not verified
- A fresh Chromium browser render (localhost access blocked by administrative policy).
- Mobile taps for the new Settings disclosure, actual file picker/download, Android/PWA installation, and visual resemblance to approved mockups.
- The previously observed `replaceChildren` exception in V10 monthly refresh requires a proper-origin browser investigation.

## Deployment
Do NOT deploy yet. Hold for final visual/interactive acceptance and release preparation; preserve production data backup.
