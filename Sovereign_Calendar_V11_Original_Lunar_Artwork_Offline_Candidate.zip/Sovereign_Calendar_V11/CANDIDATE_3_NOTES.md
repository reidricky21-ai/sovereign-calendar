# V11 Visual Candidate 3 — offline release-gate checkpoint

Corrected a real Candidate 2 mismatch: its backup/update script still identified Candidate 1. This release updates the script, manifest, header and service-worker cache label together.

Run `python release_gate.py` from the extracted directory for syntax, references, unique IDs, and version consistency; run `node offline_test.js` for calendar invariants. These are static/algorithmic tests, NOT browser/PWA acceptance tests.

The local headless Chromium attempt timed out. Android/PWA appearance, taps, fullscreen, service-worker activation and actual backup/restore round trips remain unverified. Do not replace the live Netlify deployment with this candidate.
