# Sovereign Calendar V11 — Acceptance gate

## Automated checks now completed
- `python release_gate.py`: version checks, 166 unique control IDs, linked assets, 14 JavaScript syntax checks.
- `node offline_test.js`: 1,200 Sovereign operator days, 250 exact month boundaries, 68 Praxis resets, including partial final days.
- `node backup_roundtrip_test.js`: serialized and restored sample events, Praxis journal, gallery favorites, pair reflections, and personal Praxis commencement in an isolated simulated environment; confirms stored values match exactly.

## Still required before production
- Real Chromium/Android render check, five dock destinations, visual match to approved mockups.
- Test research expander and every original instrument, in particular iframe 72-Node Explorer.
- Real-browser backup download/upload and existing-user migration (simulated test is not proof of real download behavior).
- Responsive viewport at 360, 390, 430, tablet and desktop widths; inspect dialogs and bottom dock.
- Service worker install, activation, cache upgrades, fresh versus existing users, offline reload.
- Accessibility: visible focus, keyboard, screen-reader labels, reduced motion; image fullscreen/close.
- Verify no user data is lost across an update; export backup before any installation.

## Browser environment limitation
A local Playwright/Chromium test failed `Page.goto` with `net::ERR_BLOCKED_BY_ADMINISTRATOR` for file: navigation. Earlier local-server testing was also blocked. Static and simulated checks are not a substitute for interactive visual acceptance. **Do not deploy to production yet.**
