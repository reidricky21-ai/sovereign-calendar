Source artwork integration — 2026-10-21

Eight user-provided original images integrated as preserved-composition optimized WebP files in artwork/source-lunar, displayed in the Daily Teacher below astronomical Moon events. Two overview diagrams are featured, and all eight are accessible in an expandable source artwork view. Astronomical phase calculations and mathematical month remain independent. Existing 10-piece Gallery remains untouched. Original PNGs remain available in the conversation upload context, not repackaged here.

Checks: JavaScript parse, asset references, ZIP integrity. Real-browser and installed-PWA upgrades not yet tested.
