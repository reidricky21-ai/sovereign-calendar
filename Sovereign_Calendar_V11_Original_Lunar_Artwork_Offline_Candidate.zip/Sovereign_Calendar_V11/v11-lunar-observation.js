(()=>{'use strict';
const $=id=>document.getElementById(id), DAY=86400000;
let events=[],loaded=false;
const symbols={'New Moon':'🌑','First Quarter':'🌓','Full Moon':'🌕','Last Quarter':'🌗'};
function parseCSV(text){const lines=text.replace(/^\uFEFF/,'').trim().split(/\r?\n/);return lines.slice(1).map(line=>{const c=line.split(',');if(c[0]!=='moon'||!symbols[c[1]]||!c[2])return null;const ms=Date.parse(c[2].replace(' ','T')+'Z');return Number.isFinite(ms)?{name:c[1],ms}:null}).filter(Boolean).sort((a,b)=>a.ms-b.ms)}
function labelDate(ms){return new Date(ms).toLocaleString(undefined,{year:'numeric',month:'short',day:'numeric',hour:'numeric',minute:'2-digit'})}
function sameCivilDay(a,b){return a.getFullYear()===b.getFullYear()&&a.getMonth()===b.getMonth()&&a.getDate()===b.getDate()}
function phaseForDay(date){
 const start=new Date(date.getFullYear(),date.getMonth(),date.getDate());
 const noon=new Date(start.getTime()+12*3600000);
 const approx=window.SovereignEngine?.moonPhase(noon);
 const todayEvents=events.filter(e=>sameCivilDay(new Date(e.ms),date));
 return {approx,todayEvents};
}
function draw(){const out=$('v11MoonName');if(!out)return;
 const chosen=window.__sovGetChosen?.() || new Date();const date=new Date(chosen);
 if(!Number.isFinite(date.getTime()))return;
 const {approx,todayEvents}=phaseForDay(date);
 if(!approx)return;
 const major=todayEvents[0];
 out.textContent=major?major.name:approx.label;
 $('v11MoonIcon').textContent=major?symbols[major.name]:['🌑','🌒','🌓','🌔','🌕','🌖','🌗','🌘'][Math.floor(((approx.phaseFraction+1/16)*8))%8];
 $('v11MoonIllum').textContent='Approximate illumination: '+approx.pct.toFixed(1)+'%';
 $('v11MoonDate').textContent='Selected: '+date.toLocaleDateString(undefined,{weekday:'long',year:'numeric',month:'long',day:'numeric'})+(major?' · major phase occurs today':' · daily phase estimate');
 const list=$('v11MoonEvents');list.replaceChildren();
 const at=new Date(date.getFullYear(),date.getMonth(),date.getDate()).getTime();
 const next=events.filter(e=>e.ms>=at).slice(0,4);
 if(next.length===0){list.textContent=loaded?'No dated major-phase records available for this date.':'Loading dated lunar events…';return;}
 next.forEach(e=>{const card=document.createElement('div');card.className='v11-moon-event';const b=document.createElement('b');b.textContent=symbols[e.name]+' '+e.name;const v=document.createElement('span');v.textContent=labelDate(e.ms);card.append(b,v);list.append(card)});
}
async function init(){if(!$('v11MoonName'))return;
 try{const r=await fetch('./astronomical_events.csv');if(!r.ok)throw Error('data unavailable');events=parseCSV(await r.text());loaded=true;}catch(e){loaded=true;$('v11MoonSource').textContent='Daily Moon phase and illumination are approximate; the offline major-phase table could not be loaded. The mathematical month remains independent.';}
 draw();
 const target=$('heroDate');if(target){new MutationObserver(()=>draw()).observe(target,{childList:true,characterData:true,subtree:true});}
 document.addEventListener('visibilitychange',()=>{if(!document.hidden)draw()});
 window.SovereignLunarObservation={phaseForDay,majorEvents:()=>events.slice(),refresh:draw};
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
