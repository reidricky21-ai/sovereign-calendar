# Gallery reference rebuild — offline checkpoint

- Replaced generic Gallery intro with artwork-led Crown spotlight, curated collection filtering, two-column mobile masonry, and preserved fullscreen/detail/favorite/ambient actions.
- Fix: original PNG paths in manifest are not packaged. Viewer download now explicitly uses included WebP image (not falsely labeled original). Original PNG exports remain pending source-file restoration.
- Uses existing artwork assets and existing favorites storage key.
- Not a production release. Confirm gallery rendering, modal, service worker, favorites/backup, and Android behavior before Netlify deployment.
