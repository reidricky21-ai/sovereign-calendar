# V11 illustrated Praxis reconstruction — offline preview

- Added a distinct artwork-led Praxis chamber based on the approved mockup, using existing user-supplied images.
- Live Praxis and Sovereign operators read from `SovereignPraxisMonth.at(Date.now())`; no calendar mathematics changed.
- Daily Teacher, Lessons, Journal, and Personal Journey actions link to existing V9/V11 functionality.
- Lesson descriptions are safe, optional and editorial; original study controls remain below the illustrated chamber.
- **Outstanding:** actual mobile browser render, device PWA update test, journaling on real origin, independent screen-by-screen mockup acceptance.
- Do not deploy to Netlify yet.
