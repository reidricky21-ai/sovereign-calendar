# V11 Comparative Grammar — Offline Candidate

Adds an optional Qe/Ne/Te interpretive panel to the existing 64-pair Alignment Atlas. The first operator remains the referent, second the comparison domain. All 64 pairs receive a structural question, with select source/user-developed relationships getting refined questions. Existing eight authored Praxis interpretations remain unchanged, as do the 56 UNRESOLVED Atlas judgments and all calendar mathematics.

Interpretive safeguards: mode is user-selected, not a calculated astronomical or grammatical fact. The Sovereign–Praxis pairing has a different origin than arbitrary Akinraic grammatical chaining. The UI explicitly labels working questions as proposed interpretations, not certified translations. No scoring, grading, compelled journaling, or claims about spiritual worth.

Release gate: offline candidate only. Real Android, cache upgrade, storage persistence, accessibility and browser interaction must be verified before deploying.
