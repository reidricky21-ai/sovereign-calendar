/* V11 Stage C — personal commencement is participation metadata, NEVER calendar math. */
(()=>{'use strict';
const E=Date.UTC(2024,2,10,9), M=2551392000, FOUND=32, START_KEY='sov-v11-personal-praxis-start', NOTES_KEY='sov-v11-alignment-reflections';
const $=id=>document.getElementById(id), names={Se:'Essence',Me:'Identity',Le:'Truth',Da:'Structure',Ye:'Purpose',Ka:'Force',Re:'Resonance',Ha:'Hiddenness'};
const authored={
'Se-Se':['Preserving Essence','What is essential, and what evidence supports this understanding?','world-tree'],
'Me-Me':['Knowing Identity','What can be genuinely known about identity, and what is only assumed?','witness-cosmic-axis'],
'Le-Ye':['Alignment with Truth','How can purpose respond to what is actually true?','crown-field'],
'Da-Da':['Establishing Structure','What foundations make deliberate action possible?','crown-field'],
'Ye-Ka':['Acting with Purpose','Does the action actually express its stated purpose?','operator-praxis-circle'],
'Ha-Re':['Receiving the Hidden','What remains concealed, and what information could make it clearer?','ha-continuity'],
'Re-Le':['Testing through Feedback','What does this returning observation establish, and what remains unresolved?','crown-field'],
'Ka-Ha':['Renewing through Sovereignty','How can deliberate agency create conditions for change?','ha-continuity']};
const pos=()=>Math.floor((Date.now()-E)/M), bound=i=>E+i*M, ym=i=>[Math.floor(i/18)+1,((i%18)+18)%18+1];
function start(){try{const x=JSON.parse(localStorage.getItem(START_KEY));return Number.isSafeInteger(x)&&x>=FOUND?x:FOUND}catch{return FOUND}}
function savedNotes(){try{const obj=JSON.parse(localStorage.getItem(NOTES_KEY)||'{}');return obj&&typeof obj==='object'&&!Array.isArray(obj)?obj:{}}catch{return {}}}
function mode(){const v=$('v11StartMode').value;const current=Math.max(FOUND,pos());if(v==='current')return current;if(v==='founding')return FOUND;const year=Number($('v11StartYear').value),month=Number($('v11StartMonth').value);if(!Number.isSafeInteger(year)||year<2||year>9999||!Number.isInteger(month)||month<1||month>18)throw Error('Enter a valid year and month');const idx=(year-1)*18+(month-1);if(idx<FOUND)throw Error('Choose Year 2 Month 15 or later');return idx}
function report(){const idx=start(),[y,m]=ym(idx);const current=pos();$('v11StartInfo').textContent=`Personal start: Year ${y}, Month ${m} · ${new Date(bound(idx)).toISOString().replace('T',' ').replace('.000Z',' UTC')}. ${current<idx?'Your selected start is in the future.':'Your personal journey has commenced.'} All shared calendar alignments remain unchanged.`;}
let active='Le-Ye';
function selected(p){active=p;const d=authored[p];$('v11PairChoice').value=p;const content=$('v11PairExplain');content.replaceChildren();const box=document.createElement('div');box.className='v11-pair-guide';const title=document.createElement('h3');title.textContent=p+' — '+(d?d[0]:'Operator encounter');const desc=document.createElement('p');desc.textContent=d?d[1]:`How does ${names[p.split('-')[0]]||p} relate to the current Praxis principle?`;const state=document.createElement('small');state.textContent='PROPOSED philosophical interpretation · Not a certified Akinraic translation, objective forecast, or judgment';box.append(title,desc,state);content.append(box);$('v11PairNote').value=savedNotes()[p]||'';$('v11PairMessage').textContent='';}
function init(){if(!$('v11StartMonth'))return;for(let i=1;i<=18;i++){let opt=document.createElement('option');opt.value=i;opt.textContent='Month '+i;$('v11StartMonth').append(opt)}
const origin=start(),[y,m]=ym(origin);$('v11StartYear').value=y;$('v11StartMonth').value=m;$('v11StartMode').value='custom';report();
$('v11StartMode').addEventListener('change',()=>{const v=$('v11StartMode').value,idx=v==='founding'?FOUND:Math.max(FOUND,pos());if(v!=='custom'){const [y,m]=ym(idx);$('v11StartYear').value=y;$('v11StartMonth').value=m}});
$('v11SaveJourney').onclick=()=>{try{const idx=mode();localStorage.setItem(START_KEY,JSON.stringify(idx));report()}catch(e){$('v11StartInfo').textContent=e.message}};
for(const pair of Object.keys(authored)){const o=document.createElement('option');o.value=pair;o.textContent=pair+' · '+authored[pair][0];$('v11PairChoice').append(o)}$('v11PairChoice').onchange=()=>selected($('v11PairChoice').value);
$('v11PairSave').onclick=()=>{try{const notes=savedNotes();notes[active]=$('v11PairNote').value;localStorage.setItem(NOTES_KEY,JSON.stringify(notes));$('v11PairMessage').textContent='Reflection saved locally and included in full backup.'}catch{$('v11PairMessage').textContent='Unable to save; copy your note elsewhere.'}};
$('v11PairClear').onclick=()=>{if(!confirm('Clear your reflection for '+active+'?'))return;const notes=savedNotes();delete notes[active];localStorage.setItem(NOTES_KEY,JSON.stringify(notes));$('v11PairNote').value='';$('v11PairMessage').textContent='Reflection cleared.'};
$('v11OpenPairArt').onclick=()=>{window.SovereignVisualCodex?.openArtwork(authored[active][2])};
// Link existing monthly interval rows to content without altering the original timeline engine.
$('v10Rows')?.addEventListener('click',e=>{const row=e.target.closest('.v10-pair-row');if(!row)return;const p=row.querySelector('strong')?.textContent?.trim().replace('–','-');if(p&&authored[p])selected(p);else if(p&&p.includes('-')){const [a,b]=p.split('-');active=p;const box=$('v11PairExplain');box.replaceChildren();const d=document.createElement('div');d.className='v11-pair-guide';const h=document.createElement('h3');h.textContent=p+' — Unresolved interpretation';const q=document.createElement('p');q.textContent=`Sovereign ${names[a]||a} and Praxis ${b}: this encounter has no individually approved interpretation yet.`;d.append(h,q);box.append(d);$('v11PairNote').value=savedNotes()[p]||'';}});
selected('Le-Ye');}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();