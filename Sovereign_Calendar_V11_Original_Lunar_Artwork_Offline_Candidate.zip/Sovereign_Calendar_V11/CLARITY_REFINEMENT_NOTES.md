# V11 two-calendar clarity refinement

- Home: added concise accessible comparison after active pair, below the hero visual.
- Calendar: added two operator sequences and expandable why-they-differ explanation after month navigation.
- Clarifies 09:00 UTC versus founding Praxis 08:02:24 UTC without changing timekeeping.
- No alterations to calendar or persistence scripts, personal settings, imagery, or navigation.
- Pure HTML/CSS patch; browser acceptance remains necessary.
