const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const engine=require('./engine.js');
const DAY=86400000,MONTH=2551392000,zero=engine.EPOCH;
assert.equal(engine.OPERATORS.length,8);
const order=['Se','Me','Le','Da','Ye','Ha','Re','Ka'];
for(let k=0;k<1200;k++){
 const ms=zero+k*DAY;
 assert.equal(engine.calculate(ms).op[0],order[k%8]);
}
for(let k=0;k<250;k++){
 const boundary=zero+k*MONTH;
 const at=engine.calculate(boundary),before=engine.calculate(boundary-1);
 assert.equal(at.globalMonth,k);
 assert.equal(at.dayInMonth,1);
 assert.equal(before.globalMonth,k-1);
 assert.equal(before.dayInMonth,30);
 assert.equal(engine.monthBoundary(k).getTime(),boundary);
}
let ctx={window:{},document:{getElementById:()=>null,addEventListener:()=>{}},Date,Math,Intl,setInterval:()=>{},console};
vm.createContext(ctx);vm.runInContext(fs.readFileSync('./v10-dual.js','utf8'),ctx);
// V10 exposes its pure calendar API in init() after DOM is available.
// Read only one month-boundary test harness (do not alter production source).
const src=fs.readFileSync('./v10-dual.js','utf8').replace('if(!$\u0028\u0027v10Live\u0027\u0029)return;',"if(!$('v10Live'))return;");
let testSrc=src.replace('})();','window.__qaAt=at;})();');
const fake={};let testCtx={window:fake,document:{getElementById:()=>null},Date,Math,Intl,setInterval:()=>{},console};
vm.createContext(testCtx);vm.runInContext(testSrc,testCtx);
const at=fake.__qaAt;
assert.equal(at(zero+32*MONTH-1).active,false);
assert.equal(at(zero+32*MONTH).active,true);
const praxis=['Se','Me','Ye','Da','Ka','Re','Le','Ha'];
for(let k=32;k<100;k++){
 const s=zero+k*MONTH;
 for(let d=0;d<30;d++){
   const t=s+d*DAY;
   if(t>=s+MONTH)break;
   const state=at(t);
   assert.equal(state.p,praxis[d%8],`month ${k} day ${d}`);
   assert.equal(state.dayNumber,d+1);
   assert.ok(state.praxisDayEnd<=s+MONTH);
 }
 assert.equal(at(s+MONTH-1).praxisDayEnd,s+MONTH);
 assert.equal(at(s+MONTH).p,'Se');
}
console.log('PASS: 1200 sovereign operator days; 250 exact month boundaries; 68 praxis reset cycles; partial final days.');
