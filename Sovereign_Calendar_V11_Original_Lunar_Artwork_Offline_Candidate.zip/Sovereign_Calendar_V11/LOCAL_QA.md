# V11 Visual Candidate 2 — Offline verification

## Automated checks passed
- 1,200 uninterrupted Sovereign operator days.
- 250 exact 29.53-day Sovereign month-boundary transitions.
- 68 independent Praxis monthly resets, including partial final days.
- 166 unique HTML element IDs; 14 original instrument panes remain.
- Four direct panel links, 18 HTML external file references, and six CSS artwork background references resolve locally.
- All packaged JavaScript parses successfully with Node.
- Release header, manifest, and service-worker cache identifier now label Visual Candidate 2.

## Not verified
Local Chromium browser was previously blocked from navigating to both localhost and file:// URLs; browser screenshots, tap navigation, responsive overflow, Android installed-PWA upgrades, real backup/restore round-trips, and offline service worker installation still require interactive QA.

## Deployment guidance
Do not use production Netlify deployment yet. This remains an offline candidate, not the final V11 stable release. Preserve a full existing-app backup before any future trial.


Candidate 4 presentation refinement: settings collapsed by default; research menu condensed; hero responsive typography refined. No engine modifications.
