/* Progressive accessibility enhancements; no calendar or storage writes. */
(()=>{'use strict';
function init(){
 const dock=document.getElementById('visualDock');
 const skip=document.createElement('a');skip.className='v11-skip';skip.href='#v11MainFocus';skip.textContent='Skip navigation to current screen';document.body.prepend(skip);
 const target=document.createElement('div');target.id='v11MainFocus';target.tabIndex=-1;target.className='v11-sr-only';dock?.insertAdjacentElement('afterend',target);
 const status=document.createElement('div');status.className='v11-access-status';status.setAttribute('role','status');status.setAttribute('aria-live','polite');status.setAttribute('aria-atomic','true');document.body.append(status);
 function current(){return dock?.querySelector('.dock-item.active')||dock?.querySelector('.dock-item[aria-current="page"]')}
 function sync(){dock?.querySelectorAll('.dock-item').forEach(b=>{const active=b===current();if(active)b.setAttribute('aria-current','page');else b.removeAttribute('aria-current')})}
 sync();
 dock?.addEventListener('click',e=>{const button=e.target.closest('.dock-item');if(!button)return;requestAnimationFrame(()=>{sync();status.textContent=button.textContent.trim()+' screen';})});
 dock?.addEventListener('keydown',e=>{if(!['ArrowLeft','ArrowRight','Home','End'].includes(e.key))return;const buttons=[...dock.querySelectorAll('.dock-item:not([disabled])')];const currentIndex=buttons.indexOf(document.activeElement);if(currentIndex<0)return;e.preventDefault();let next=e.key==='Home'?0:e.key==='End'?buttons.length-1:(currentIndex+(e.key==='ArrowRight'?1:-1)+buttons.length)%buttons.length;buttons[next].focus()});
 skip.addEventListener('click',()=>{const el=current();const pane=el&&document.getElementById(el.dataset.target+'Pane');setTimeout(()=>{(pane||target).setAttribute('tabindex','-1');(pane||target).focus({preventScroll:true});(pane||target).scrollIntoView({behavior:'instant',block:'start'})},0)});
 document.querySelectorAll('details.v11-fold').forEach(d=>{const s=d.querySelector(':scope > summary');if(s&& !s.getAttribute('aria-label'))s.setAttribute('aria-label',s.textContent.trim()+'; expand or collapse')});
 document.querySelectorAll('button').forEach(b=>{if(!b.getAttribute('type')&&!b.closest('form'))b.type='button'});
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();
