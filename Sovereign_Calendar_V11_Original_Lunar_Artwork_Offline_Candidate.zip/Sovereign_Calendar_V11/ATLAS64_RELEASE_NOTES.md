# V11 — Complete 64-Pair Alignment Reference

All eight Sovereign operators and eight distinct Praxis teaching positions appear in an interactive 8×8 index. Eight earlier authored interpretations remain authored, while 56 combinations explicitly read UNRESOLVED. Reference exploration never changes calendar arithmetic. A live event or current-pair action can synchronize the index to the computed pairing. New CSS/JS are precached with a bumped service-worker cache key.

Release status: Offline test candidate only; Android persistence and PWA migration remain unverified.
