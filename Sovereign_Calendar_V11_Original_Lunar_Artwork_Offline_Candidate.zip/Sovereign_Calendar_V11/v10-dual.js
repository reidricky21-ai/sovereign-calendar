/* V10 dual calendar: month-anchored Praxis cycle. UTC calculations, no user data mutation. */
(function(){'use strict';
const epoch=Date.UTC(2024,2,10,9), day=86400000, month=2551392000;
const praxisStartMonth=32; // Year 2 Month 15 = zero-based 18+14
const sovereign=['Se','Me','Le','Da','Ye','Ha','Re','Ka'];
const praxis=['Se','Me','Ye','Da','Ka','Re','Le','Ha'];
const teaching={Se:'Preserve',Me:'Know',Ye:'Align',Da:'Establish',Ka:'Act',Re:'Receive',Le:'Truth',Ha:'Renew'};
const labels={Se:'Essence',Me:'Identity',Le:'Truth',Da:'Structure / Authority',Ye:'Purpose',Ha:'Hiddenness',Re:'Resonance',Ka:'Force'};
const affirmations={
 'Se-Se':['Preserving Essence','What is essential, and what evidence supports that understanding?'],
 'Me-Me':['Knowing Identity','What persists through change, and how can it be known?'],
 'Le-Ye':['Aligning with Truth','Does purpose respond to reality rather than trying to redefine it?'],
 'Da-Da':['Establishing Structure','What foundations and relationships enable reliable action?'],
 'Ye-Ka':['Acting with Purpose','How well does action express its stated purpose?'],
 'Ha-Re':['Receiving the Hidden','What remains unrecognized, and what can feedback reveal?'],
 'Re-Le':['Testing Truth through Feedback','What does the response establish, and what remains uncertain?'],
 'Ka-Ha':['Renewing through Sovereignty','How can agency support change without forcing an outcome?']
};
const $=id=>document.getElementById(id), mod=(a,b)=>((a%b)+b)%b;
function at(ms){
 const idx=Math.floor((ms-epoch)/month),start=epoch+idx*month,end=start+month;
 const sod=Math.floor((ms-epoch)/day),s=sovereign[mod(sod,8)];
 if(idx<praxisStartMonth)return {active:false,idx,start,end,s,sovereignDayEnd:epoch+(sod+1)*day};
 const pi=Math.floor((ms-start)/day),p=praxis[mod(pi,8)];
 return {active:true,idx,start,end,s,p,dayNumber:pi+1,praxisDayEnd:Math.min(start+(pi+1)*day,end),sovereignDayEnd:epoch+(sod+1)*day,pair:s+'-'+p};
}
function fmt(ms){return new Intl.DateTimeFormat('en-CA',{dateStyle:'medium',timeStyle:'short',timeZone:'UTC',hourCycle:'h23'}).format(new Date(ms))+' UTC'}
function duration(ms){const x=Math.max(0,Math.floor(ms/1000));return Math.floor(x/86400)+'d '+String(Math.floor(x%86400/3600)).padStart(2,'0')+'h '+String(Math.floor(x%3600/60)).padStart(2,'0')+'m '+String(x%60).padStart(2,'0')+'s'}
function title(idx){const y=Math.floor(idx/18)+1,m=mod(idx,18)+1;return 'Year '+y+' · Praxis Month '+m}
function pairLabel(s,p){const q=affirmations[s+'-'+p];return q?q:['Sovereign '+labels[s]+' · Praxis '+teaching[p],'How does the '+labels[s].toLowerCase()+' operator relate to '+teaching[p].toLowerCase()+' in this encounter?']}
function range(idx){const start=epoch+idx*month,end=start+month;let breaks=[start,end];
 let t=epoch+Math.ceil((start-epoch)/day)*day;while(t<end){if(t>start)breaks.push(t);t+=day;}
 t=start+day;while(t<end){breaks.push(t);t+=day;}
 breaks.sort((a,b)=>a-b);breaks=[...new Set(breaks)];
 return breaks.slice(0,-1).map((v,i)=>({...at(v+1),a:v,b:breaks[i+1]}));
}
let showing=32;
function renderMonth(){const start=epoch+showing*month,end=start+month;
 $('v10MonthTitle').textContent=title(showing);
 $('v10Boundary').textContent=fmt(start)+' → '+fmt(end)+' (exact mathematical boundaries)';
 const grid=$('v10Rows');grid.replaceChildren();
 const seg=range(showing);let dayno=0;let previous='';
 for(const a of seg){const row=document.createElement('button');row.type='button';row.className='v10-pair-row';
 const daykey=a.dayNumber;const first=daykey!==previous;previous=daykey;if(first)dayno++;
 const label=pairLabel(a.s,a.p), hours=((a.b-a.a)/3600000).toFixed(2);
 row.innerHTML='<span class="v10-row-day">'+(first?'Day '+a.dayNumber:'↳')+'</span><strong>'+a.s+'–'+a.p+'</strong><span>'+label[0]+'</span><small>'+hours+'h</small>';
 row.title=fmt(a.a)+' – '+fmt(a.b);
 row.onclick=()=>{$('v10Selected').innerHTML='<h3>'+a.s+'–'+a.p+' · '+label[0]+'</h3><p>'+label[1]+'</p><p class="muted">'+fmt(a.a)+' → '+fmt(a.b)+'</p><small>Interpretive inquiry, not a canonical translation or factual prediction.</small>';};grid.appendChild(row);
 }
 const k=at(start+1);$('v10Opening').textContent='At month opening: '+(k.active?k.p+' Praxis / '+k.s+' Sovereign':'Praxis not yet founded')+'. '+seg.length+' distinct pairing intervals.';
}
function renderLive(){const x=at(Date.now());const el=$('v10Live');if(!el)return;
 if(!x.active){el.innerHTML='<strong>Praxis Calendar begins '+fmt(epoch+32*month)+'</strong><p class="muted">Founding anchor: Year 2, Month 15. Calendar calculations remain available after that date.</p>';return;}
 const [name,question]=pairLabel(x.s,x.p);
 el.innerHTML='<div class="v10-dual"><div><small>SOVEREIGN</small><strong>'+x.s+'</strong><span>'+labels[x.s]+'</span></div><div><small>PRAXIS · DAY '+x.dayNumber+'</small><strong>'+x.p+'</strong><span>'+teaching[x.p]+'</span></div></div><h3>'+x.pair+' — '+name+'</h3><p>'+question+'</p><p class="muted">Next Sovereign shift: '+fmt(x.sovereignDayEnd)+' · '+duration(x.sovereignDayEnd-Date.now())+'<br>Next Praxis shift: '+fmt(x.praxisDayEnd)+' · '+duration(x.praxisDayEnd-Date.now())+'</p>';
 const m=Math.floor((Date.now()-epoch)/month);if(showing!==m && !document.activeElement?.closest?.('#v10MonthControls')){ /* keep manually chosen month */ }
}
function init(){if(!$('v10Live'))return;const current=at(Date.now());showing=Math.max(praxisStartMonth,current.idx);
 $('v10Prev').onclick=()=>{showing=Math.max(praxisStartMonth,showing-1);renderMonth()};
 $('v10Next').onclick=()=>{showing++;renderMonth()};
 $('v10Today').onclick=()=>{showing=Math.max(praxisStartMonth,at(Date.now()).idx);renderMonth()};
 renderLive();renderMonth();setInterval(renderLive,1000);
 // Shared API for V9 Daily Teacher, without changing self-paced selection.
 window.SovereignPraxisMonth={at,teaching};
}
window.SovereignPraxisMonth={at,teaching};
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
