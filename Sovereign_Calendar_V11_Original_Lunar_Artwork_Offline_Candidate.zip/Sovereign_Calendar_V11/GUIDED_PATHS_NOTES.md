# V11 Guided Paths: usability refinement

This candidate adds a small "Where to next" navigation row immediately after the leading visual / live chamber of each main tab (Home, Calendar, Praxis, Codex, Gallery). The links scroll to existing content. When a target lives in a folded `<details>` section, the link opens it first. Core artwork, operator time engine, monthly resets, events, personal commencement, backup format and Gallery assets were not changed.

Scope: navigation clarity only. Does not add a new module, replace the five-tab dock, or rewrite source material. No Netlify deployment was performed.

QA: JavaScript syntax; cache manifest path resolution; calendar navigation and backup round-trip regression scripts. Android touch UX and installed-PWA updates require user testing.
