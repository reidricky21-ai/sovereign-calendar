# V11 Collapsible Sections — Offline QA

The original latest Dual Calendar Clarity package is the baseline. This change introduces 14 native HTML `details` accordion sections with keyboard-accessible summaries. No calendar engine or data schema change.

Collapsed by default: Home contextual plate, 8-day reference, Light Ledger, research tools, two-path reference; Codex definition lock, scope laboratory, grammar validity; Praxis Sutras of Alignment; Dual Calendar Alignment Journey reference; Atlas Qe/Ne/Te and operator-card reference plus I Ching manuscript list; calendar mechanics.

Kept immediately visible: Home hero and alignment, daily focus and clocks, Calendar month and date grid, selected-day details, Personal Praxis commencement, Praxis entry form, Gallery controls and collection, Codex introductory chamber. Native summaries retain keyboard navigation and `aria` semantics. Internal hash navigation opens an ancestor fold.

Offline tests: JavaScript syntax, 1200 operator days, 250 month boundaries, 68 Praxis resets, navigation, five-category backup roundtrip, all precache assets, ZIP CRC. Browser/Android manual review outstanding; folding large dynamic sections needs user acceptance.
