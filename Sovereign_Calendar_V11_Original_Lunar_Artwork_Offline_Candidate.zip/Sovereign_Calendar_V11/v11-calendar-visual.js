/* V11 illustrated Calendar. Mathematical dates from SovereignEngine; V10 timeline retained. */
(()=>{'use strict';
const $=id=>document.getElementById(id), E=window.SovereignEngine;
if(!$('v11CalendarFeature')||!E)return;
const praxis=['Se','Me','Ye','Da','Ka','Re','Le','Ha'];
const teaching={Se:'Preserve',Me:'Know',Ye:'Align',Da:'Establish',Ka:'Act',Re:'Receive',Le:'Truth',Ha:'Renew'};
const fmt=t=>new Date(t).toLocaleString('en-GB',{day:'numeric',month:'short',hour:'2-digit',minute:'2-digit',timeZone:'UTC',hour12:false});
const monthText=t=>new Date(t).toLocaleString('en-GB',{month:'long',year:'numeric',timeZone:'UTC'});
let selected=E.calculate(new Date()).globalMonth;
function render(){
 const start=E.EPOCH+selected*E.MONTH,end=start+E.MONTH;
 const y=Math.floor(selected/18)+1,m=((selected%18)+18)%18+1;
 $('v11CalPeriod').textContent=`YEAR ${y} · MONTH ${m} / 18`;
 $('v11CalCivil').textContent=`${fmt(start)} — ${fmt(end)} UTC`;
 $('v11CalTitle').textContent=monthText(start);
 const live=E.calculate(new Date());$('v11CalLive').textContent=`CURRENT · ${live.op[0]} — ${window.SovereignPraxisMonth?.at(Date.now()).p || '—'}`;
 const list=$('v11CalJourney');list.replaceChildren();
 for(let i=0;i<8;i++){
   const t=start+i*E.DAY;if(t>=end)break;
   const beforeFounding=selected<32;
   const s=E.calculate(new Date(t)).op[0],p=praxis[i%8];
   const row=document.createElement('button');row.type='button';row.className='v11-calendar-day';
   row.innerHTML=`<span class="v11-calendar-orb">${i+1}</span><span class="v11-calendar-daytext"><b>${beforeFounding?s:s+' — '+p}</b><small>${fmt(t)} UTC · ${beforeFounding?'Praxis not yet founded':teaching[p]}</small></span><span aria-hidden="true">›</span>`;
   row.addEventListener('click',()=>{window.dispatchEvent(new CustomEvent('v11:alignment-instant',{detail:{timestamp:t}}));$('v11AlignmentAtlas')?.scrollIntoView({behavior:'smooth',block:'start'});});
   list.append(row);
 }
 $('v11CalNote').textContent=selected<32?'Before Praxis founding: Sovereign chronology remains available; no historical Praxis instruction is assigned.':'Pairings shown at each Praxis day opening. The Sovereign operator changes at its own time within many Praxis days; open the detailed timeline for every transition.';
}
function move(delta){
 const target=selected+delta;
 if(selected>=32 && target>=32){
   const button=$(delta<0?'v10Prev':'v10Next');
   if(button){button.click();return;}
 }
 selected=target;render();
}
$('v11CalBack')?.addEventListener('click',()=>move(-1));
$('v11CalForward')?.addEventListener('click',()=>move(1));
$('v11CalToday')?.addEventListener('click',()=>{selected=E.calculate(new Date()).globalMonth;render();$('v10Today')?.click();});
$('v11CalTimeline')?.addEventListener('click',()=>$('v10MonthControls')?.scrollIntoView({behavior:'smooth',block:'start'}));
$('v11CalOpen')?.addEventListener('click',()=>$('v10MonthControls')?.scrollIntoView({behavior:'smooth',block:'start'}));
['v10Prev','v10Next','v10Today'].forEach(id=>$(id)?.addEventListener('click',()=>{
 if(id==='v10Today')selected=E.calculate(new Date()).globalMonth;
 else if(id==='v10Prev'&&selected>32)selected--;
 else if(id==='v10Next')selected++;
 render();
}));
window.addEventListener?.('v11:alignment-month',e=>{const t=e.detail?.timestamp;if(!Number.isFinite(t))return;selected=E.calculate(new Date(t)).globalMonth;render();});
render();
})();
