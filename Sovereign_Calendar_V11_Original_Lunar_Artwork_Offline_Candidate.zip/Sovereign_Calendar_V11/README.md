# Sovereign Calendar V11 — Grand Visual Overhaul (Offline Candidate 2)

**Do not deploy to production yet.** This is the consolidated visual redesign for pre-release testing.

Changes: new five-destination bottom dock, expandable access to all 14 original instruments, full-screen original-art home hero, distinct Calendar/Praxis/Codex/Gallery illustrated intros, gold-and-obsidian component skin, responsive mobile treatment, keyboard focus and reduced-motion support.

**Preserved:** original engine.js, v10-dual.js, 72-node-explorer directory, v8/v9 study scripts, event & journal controls, gallery, personal Praxis and reflections, service worker.

**Not yet certified:** browser interaction, mobile PWA upgrade, Android rendering, gallery backup/restore, full responsive visual acceptance. No new Netlify deployment recommended until checked.

Local quick preview: run `python -m http.server 8000` from this folder, then open `http://localhost:8000` in a browser. Use a separate browser profile or origin to avoid mixing saved app data.

Automated time/math and markup tests: `node offline_test.js` and `python offline_structure_qa.py`. See LOCAL_QA.md.


Candidate 4 presentation refinement: settings collapsed by default; research menu condensed; hero responsive typography refined. No engine modifications.
