from pathlib import Path
import re, json, subprocess, sys
p=Path(__file__).parent
html=(p/'index.html').read_text()
manifest=json.loads((p/'manifest.webmanifest').read_text())
sw=(p/'sw.js').read_text(); updater=(p/'v7-release.js').read_text()
errors=[]
for name,text in [('header',html),('manifest',manifest['name'])]:
 if 'Sovereign Calendar V11' not in text: errors.append(name+' version mismatch')
if "11.0-personal-navigation.2" not in updater: errors.append('update/backup version mismatch')
if 'sovereign-calendar-v11-comparative-1' not in sw: errors.append('cache version mismatch')
ids=re.findall(r'\bid=["\']([^"\']+)',html)
if len(ids)!=len(set(ids)): errors.append('duplicate control IDs')
refs=re.findall(r'(?:src|href)=["\'](\./[^"\'#?]+)',html)
for ref in refs:
 if not (p/ref[2:]).exists(): errors.append('missing '+ref)
assets=re.findall(r"['\"](\./[^'\"]+)['\"]",sw)
for ref in assets:
 if not (p/ref[2:]).exists(): errors.append('missing cached '+ref)
for js in p.rglob('*.js'):
 result=subprocess.run(['node','--check',str(js)],capture_output=True,text=True)
 if result.returncode: errors.append(js.name+': '+result.stderr[:120])
print(json.dumps({'html_ids':len(ids),'file_refs_checked':len(refs),'service_worker_refs_checked':len(assets),'javascript_files_checked':len(list(p.rglob('*.js'))),'errors':errors},indent=2))
sys.exit(bool(errors))
