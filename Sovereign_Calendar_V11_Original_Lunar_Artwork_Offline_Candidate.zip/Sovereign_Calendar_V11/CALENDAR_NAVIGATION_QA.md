# Sovereign Calendar V11 — Calendar navigation audit

Updated: 2026-10-17

## Changes
- Corrected the new Calendar's previous/next event handling to avoid advancing the month twice when the legacy V10 controller is active.
- Synchronized the new Calendar's live operator display with the true Praxis principle instead of displaying two Sovereign values.
- Preserved the original V10 sub-day interval timeline. The illustrated eight-entry timeline represents each Praxis day's opening pairing only.
- Added `calendar_navigation_test.js` to test month movement and label synchronization with a minimal document harness.

## Passed offline tests
- `node calendar_navigation_test.js`: forward/back, month labeling, eight-entry journey, legacy navigation synchronization.
- `node offline_test.js`: 1200 Sovereign days, 250 boundaries, 68 Praxis resets.
- `node backup_roundtrip_test.js`: five-category sample restore.
- `node --check v11-calendar-visual.js`: JavaScript parses.
- ZIP integrity and artwork references present.

## Not verified
- Chrome/Android appearance at 360px and 390px for the new Calendar screen.
- Full browser interaction on a real origin; direct file navigation was blocked in this environment.
- Installed PWA upgrade and data persistence on the user's phone.

**Do not publish to Netlify yet.** This is an offline development checkpoint.
