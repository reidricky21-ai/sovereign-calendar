(()=>{'use strict';
const $=id=>document.getElementById(id), stage=$('v11AmbientStage'); if(!stage)return;
const img=$('v11AmbientPhoto'),caption=$('v11AmbientCaption'),pause=$('v11AmbientPause');
let art=[],at=0,paused=false,timer=null,previousFocus=null;
const motion=window.matchMedia('(prefers-reduced-motion: reduce)');
function fill(){if(!art.length){caption.textContent='Artwork unavailable';return}const a=art[at];img.src=a.display||a.original;img.alt=a.title;caption.textContent=a.title+' · '+a.collection}
function stop(){if(timer){clearInterval(timer);timer=null}}
function tick(){stop();if(!paused&&!motion.matches&&art.length>1)timer=setInterval(()=>{at=(at+1)%art.length;fill()},25000)}
function start(){art=(window.SovereignVisualCodex?.allArtwork?.()||[]);if(!art.length){alert('Open the Visual Codex while online first to load the artwork registry.');return}previousFocus=document.activeElement;at=0;paused=motion.matches;stage.hidden=false;document.body.style.overflow='hidden';pause.textContent=paused?'Play':'Pause';pause.setAttribute('aria-pressed',String(paused));fill();tick();$('v11AmbientClose').focus()}
function close(){stop();stage.hidden=true;document.body.style.overflow='';if(previousFocus&&typeof previousFocus.focus==='function')previousFocus.focus()}
function move(n){at=(at+n+art.length)%art.length;fill();tick()}
$('v11AmbientLaunch')?.addEventListener('click',start);
$('v11AmbientClose').onclick=close;
$('v11AmbientPrev').onclick=()=>move(-1);
$('v11AmbientNext').onclick=()=>move(1);
pause.onclick=()=>{paused=!paused;pause.setAttribute('aria-pressed',String(paused));pause.textContent=paused?'Play':'Pause';tick()};
document.addEventListener('keydown',e=>{if(stage.hidden)return;if(e.key==='Escape')close();else if(e.key==='ArrowLeft')move(-1);else if(e.key==='ArrowRight')move(1);else if(e.key==='Tab'){const buttons=[...stage.querySelectorAll('button')];if(e.shiftKey&&document.activeElement===buttons[0]){e.preventDefault();buttons.at(-1).focus()}else if(!e.shiftKey&&document.activeElement===buttons.at(-1)){e.preventDefault();buttons[0].focus()}}});
document.addEventListener('visibilitychange',()=>{if(document.hidden)stop();else if(!stage.hidden)tick()});
motion.addEventListener?.('change',()=>{if(motion.matches){paused=true;pause.textContent='Play';pause.setAttribute('aria-pressed','true')}tick()});
})();