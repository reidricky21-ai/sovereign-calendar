# V11 language clarity refinement

**Scope:** existing Codex only. A new introductory reading guide explains operators, pairs, Qe/Ne/Te and the distinctions between source scripts and grammar. Conflicting self-pairing and self-application rules remain explicitly unresolved. No breathing instructions, calendar changes, storage changes, or new navigation destinations.

**Source basis:** The Akinraic Language — Complete Reference, §§1.2–1.5; The Sovereign Ledger Language — Grammar Codex, §§II–III. The primer is an editorial explanation, not a certified translation.

**Still to test on Android:** Codex text wrapping and details interaction; app reload, Gallery and personal settings persist; PWA upgrades.
