/* Sovereign V11: precise, selectable UTC alignment. No changes to engine or personal records. */
(()=>{'use strict';
const E=window.SovereignEngine, P=window.SovereignPraxisMonth, $=id=>document.getElementById(id);
if(!E||!P||!$('v11AlignmentAtlas'))return;
const root=$('v11AlignmentAtlas');
const box=document.createElement('section');box.className='v11-align-live';box.setAttribute('aria-label','Exact alignment time explorer');
box.innerHTML=`<h4>Explore an exact moment</h4><p>Choose a UTC date and time. Both operators and their transition boundaries come from the mathematical engine, not illustrative artwork.</p><label for="v11AlignmentInstant">UTC date and time</label><div class="v11-live-controls"><input id="v11AlignmentInstant" type="datetime-local" step="60"><button id="v11AlignmentGo" type="button">Read alignment</button><button id="v11AlignmentNow" type="button">Now</button></div><p id="v11AlignmentExact" aria-live="polite"></p><div class="v11-live-actions"><button id="v11AlignmentMonth" type="button">Open this month</button><button id="v11AlignmentLesson" type="button">Explore Praxis teaching</button></div>`;
root.querySelector('.v11-align-pair')?.before(box);
const stamp=$('v11AlignmentInstant'), fmt=ms=>new Date(ms).toISOString().replace('T',' ').replace('.000Z',' UTC');
const inputFmt=ms=>new Date(ms).toISOString().slice(0,16);
let currentTime=Date.now();
function select(ms){if(!Number.isFinite(ms))return;currentTime=ms;stamp.value=inputFmt(ms);const a=P.at(ms);let msg='Sovereign: '+a.s+' · '+(a.active?'Praxis: '+a.p+' (day '+a.dayNumber+')':'Praxis not yet founded');
msg+='\nNext Sovereign transition: '+fmt(a.sovereignDayEnd);
if(a.active)msg+='\nNext Praxis transition: '+fmt(a.praxisDayEnd);
msg+='\nMonth boundary: '+fmt(a.end);
$('v11AlignmentExact').textContent=msg;
const day=a.active?a.dayNumber:1;
window.dispatchEvent(new CustomEvent('v11:alignment-select',{detail:{timestamp:ms,day,exact:true}}));
}
$('v11AlignmentGo').addEventListener('click',()=>{if(!stamp.value)return;const ms=Date.parse(stamp.value+'Z');if(Number.isFinite(ms))select(ms)});
$('v11AlignmentNow').addEventListener('click',()=>select(Date.now()));
$('v11AlignmentMonth').addEventListener('click',()=>{window.dispatchEvent(new CustomEvent('v11:alignment-month',{detail:{timestamp:currentTime}}));$('v11CalTitle')?.scrollIntoView({block:'center',behavior:'smooth'});});
$('v11AlignmentLesson').addEventListener('click',()=>{const p=$('praxisatlasPane');const nav=document.querySelector('[data-tab="praxisatlas"]');if(nav)nav.click();else document.querySelector('[data-pane="praxisatlasPane"]')?.click();(p?.querySelector('#v11PxTitle')||p)?.scrollIntoView({block:'start',behavior:'smooth'});});
window.addEventListener('v11:alignment-instant',e=>{if(Number.isFinite(e.detail?.timestamp))select(e.detail.timestamp)});
select(Date.now());
})();
