# V11 Akinraic Lexical Codex — Offline Refinement

Scope: illustrated Codex chamber only. No changes to Sovereign/Praxis epochs, calendar operator orders, personal commencement or existing storage keys.

Sources:
- Akinraic-English Prescriptive Dictionary & Lexicon, Part II: canonical glosses, Ethiopic spellings, grammatical classification, inward/outward reading, proposed primary Egyptian symbolic seal.
- The Combined Symbolic Dictionary, Part I: alternative proposed symbol correspondences.

Eight selectable entries include: Se, Me, Le, Da, Ye, Ha, Re, Ka. The symbolic alternatives appear beside, not in place of, the prescriptive forms. The symbols are modern proposed correspondences, not established translations of Egyptian inscriptions.

Contextual Qe/Ne/Te meanings remain unchanged in the Codex: outward domain, inward self, axial/invariant reference. The proposed dictionary's physical-implementation assertions were not imported as verified science, and no bodywork directions were added.

Verification: node --check v11-lexical-codex.js, offline_test.js (1,200 days; 250 months; 68 praxis cycles), calendar_navigation_test.js and backup_roundtrip_test.js passed; precache references complete. Real mobile and installed PWA tests remain outstanding.
