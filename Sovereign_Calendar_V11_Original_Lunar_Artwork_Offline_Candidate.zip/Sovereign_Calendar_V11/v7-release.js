(()=>{'use strict';
const VERSION='11.0-personal-navigation.2', PREFIX='sovereign-calendar-';
const $=id=>document.getElementById(id);
const status=(msg)=>{const el=$('updateStatus');if(el)el.textContent=msg};
const STORAGE_KEYS=['sovereign_events_v1','sovereign_praxis_v2','sovereign_v9_study_notes','sov_v6_showMoon','sov_v6_showSeasons','sov_v6_showHolidays','sov-v11-gallery-favorites','sov-v11-personal-praxis-start','sov-v11-alignment-reflections'];
const saveFile=(obj)=>{const blob=new Blob([JSON.stringify(obj,null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='sovereign-calendar-V11-backup-'+new Date().toISOString().slice(0,10)+'.json';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),10000)};
$('backupAllBtn').addEventListener('click',()=>{
  const data={};for(const k of STORAGE_KEYS){const v=localStorage.getItem(k);if(v!==null)data[k]=v}
  saveFile({format:'sovereign-calendar-full-backup',schema:1,createdAt:new Date().toISOString(),appVersion:VERSION,data});status('Backup downloaded. Store the JSON file safely.');
});
$('restoreAllInput').addEventListener('change',async(e)=>{const file=e.target.files?.[0];if(!file)return;
 try{
  if(file.size>5*1024*1024)throw Error('Backup exceeds 5 MB limit');
  const obj=JSON.parse(await file.text());if(obj?.format!=='sovereign-calendar-full-backup'||obj.schema!==1||!obj.data||typeof obj.data!=='object'||Array.isArray(obj.data))throw Error('Unrecognized backup format');
  const allowed=Object.keys(obj.data);if(allowed.some(k=>!STORAGE_KEYS.includes(k)||typeof obj.data[k]!=='string'))throw Error('Backup contains unknown or invalid values');
  for(const k of ['sovereign_events_v1','sovereign_praxis_v2']){if(k in obj.data){const a=JSON.parse(obj.data[k]);if(!Array.isArray(a)||a.length>15000)throw Error('Invalid '+k+' array');for(const item of a){if(!item||typeof item!=='object'||Array.isArray(item))throw Error('Invalid journal/event record')}}}
  if('sovereign_v9_study_notes' in obj.data){const notes=JSON.parse(obj.data.sovereign_v9_study_notes);if(!notes||typeof notes!=='object'||Array.isArray(notes)||Object.keys(notes).some(k=>!['Se','Me','Le','Da','Ye','Ka','Ha','Re'].includes(k)||typeof notes[k]!=='string'))throw Error('Invalid V9 study notes');}
  if('sov-v11-personal-praxis-start' in obj.data){const v=JSON.parse(obj.data['sov-v11-personal-praxis-start']);if(!Number.isSafeInteger(v)||v<32||v>180000)throw Error('Invalid Praxis commencement');}
  if('sov-v11-alignment-reflections' in obj.data){const v=JSON.parse(obj.data['sov-v11-alignment-reflections']);if(!v||typeof v!=='object'||Array.isArray(v)||Object.entries(v).some(([k,x])=>!/^(Se|Me|Le|Da|Ye|Ka|Re|Ha)-(Se|Me|Le|Da|Ye|Ka|Re|Ha)$/.test(k)||typeof x!=='string'||x.length>50000))throw Error('Invalid alignment reflections');}
  if('sov-v11-gallery-favorites' in obj.data){const ids=JSON.parse(obj.data['sov-v11-gallery-favorites']);if(!Array.isArray(ids)||ids.length>1000||ids.some(x=>typeof x!=='string'||x.length>100))throw Error('Invalid gallery favorites');}
  for(const k of STORAGE_KEYS.filter(x=>x.startsWith('sov_v6_'))){if(k in obj.data&&!['true','false'].includes(obj.data[k]))throw Error('Invalid preference')}
  if(!confirm('Restore this backup? It will replace your existing events, Praxis journal, and saved display preferences that are included in the file. Back up the current data first.'))return;
  for(const k of allowed)localStorage.setItem(k,obj.data[k]);status('Backup restored. Reloading app…');location.reload();
 }catch(err){status('Restore failed: '+err.message)}finally{e.target.value=''}
});
let waiting=null;let activationApproved=false;
async function checkUpdates(){if(!('serviceWorker' in navigator)){status('Service workers unavailable here; web updates require a secure HTTPS origin.');return}
 try{
  const registration=await navigator.serviceWorker.ready;
  await registration.update();
  if(registration.waiting && navigator.serviceWorker.controller){waiting=registration.waiting;$('applyUpdateBtn').hidden=false;status('An update is ready. Back up your data, then install it.');return}
  status('V'+VERSION+' · Update check complete. You may need to reopen the installed app if an update is downloading.');
 }catch(err){status('Could not check for updates: '+err.message)}
}
$('checkUpdateBtn').addEventListener('click',checkUpdates);
$('applyUpdateBtn').addEventListener('click',()=>{
 if(!waiting){status('No update is waiting to install.');return}
 if(!confirm('Install the downloaded app update now? Unsaved form input may be lost.'))return;
 activationApproved=true;waiting.postMessage({type:'SKIP_WAITING'});status('Installing update…');
});
if('serviceWorker' in navigator){navigator.serviceWorker.addEventListener('controllerchange',()=>{if(activationApproved){activationApproved=false;location.reload()}else{status('A newer app version activated. Reload the page to see its changes.')}});
 navigator.serviceWorker.ready.then(reg=>{
  if(reg.waiting&&navigator.serviceWorker.controller){waiting=reg.waiting;$('applyUpdateBtn').hidden=false;status('A new update is ready to install.');}
  else status('V'+VERSION+' · Offline-enabled PWA. Use Check for updates after deploying new files.');
  reg.addEventListener('updatefound',()=>{
    const installing=reg.installing;if(!installing)return;
    installing.addEventListener('statechange',()=>{if(installing.state==='installed'&&navigator.serviceWorker.controller){waiting=reg.waiting||installing;$('applyUpdateBtn').hidden=false;status('An update is ready to install.')}})
  });
 }).catch(()=>status('V'+VERSION+' · Offline mode not available in this browser.'))
}else status('V'+VERSION+' · Offline mode not supported.');
})();