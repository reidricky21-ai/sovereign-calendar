V11 Visual Readability Pass

Higher muted-text contrast, scalable explanatory typography, 44px minimum targets on common buttons, 16px mobile inputs, visible keyboard focus, improved narrow-screen daily panels, landscape dialog constraints, safe-area-aware content padding and forced-colors support.

No date logic, data format, artwork, gallery content or navigation script changed. Device tests still pending: TalkBack, browser zoom 200%, text enlargement, contrast measurements, touch reach, landscape.
