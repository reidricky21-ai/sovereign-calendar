# V11 Stage A — Component Inventory and Asset Audit

**Source baseline:** uploaded `Sovereign_Calendar_V10_Dual_Calendar_PWA.zip` (20 files).

## Existing features retained
Living Calendar, Operator Chambers, Light Ledger, Gregorian/Sovereign month navigation, Praxis, V9 study modules, dual calendar, Celestial–Civic alignment, 72-Node Explorer, research atlases, backup/update scripts.

## Core code
- `engine.js`: epoch and Sovereign calendar arithmetic — untouched.
- `v10-dual.js`: monthly Praxis reset and dual-calendar logic — untouched.
- `v9-study.js`: Praxis lessons and language academy — untouched.
- `v8-experience.js`: Living Calendar and chamber UI — untouched.
- `v7-release.js`: backup/update support — untouched.
- `research-data.js`: research dataset — untouched.
- `72-node-explorer/*`: standalone explorer — untouched.
- `index.html`: one navigation tab and gallery pane added; tab handler extended.
- `v11-gallery.js`, `artwork-manifest.json`, `artwork/*`: new.
- `sw.js`: bumped cache version, gallery registry and script precached; artwork cached on first use.

## Known follow-ups
1. Add gallery favorites to full export/import backups, with no data loss.
2. Implement optional personalized start-month setting (does not change canonical calculations).
3. Verify page navigation, gallery viewer, 72-Node Explorer, and existing tabs in a real browser.
4. Build dedicated ambient mode and wallpapers collection, with reduced motion.
5. Add approved source passages and operator-specific text to each plate.
6. Bundle selected high-priority artwork for genuine first-run offline availability and measure storage.
