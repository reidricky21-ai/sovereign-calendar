/* Illustrated personal commencement: a view over V11's existing, unchanged storage/validation handler. */
(()=>{'use strict';
const $=id=>document.getElementById(id), found=32, epoch=Date.UTC(2024,2,10,9), duration=2551392000, key='sov-v11-personal-praxis-start';
const ym=i=>[Math.floor(i/18)+1,i%18+1], index=(y,m)=>(y-1)*18+m-1;
function initialize(){if(!$('v11PxCommence')||!$('v11SaveJourney'))return;
 const options=$('v11PxPersonalMonth');for(let n=1;n<=18;n++){const o=document.createElement('option');o.value=n;o.textContent='Month '+n;options.append(o)}
 const radios=[...document.querySelectorAll('input[name="v11PxStartChoice"]')];
 const selected=()=>radios.find(x=>x.checked)?.value||'current';
 function saved(){let idx=found;try{const v=JSON.parse(localStorage.getItem(key));if(Number.isSafeInteger(v)&&v>=found)idx=v}catch{}return idx}
 function showSaved(){const i=saved(),[y,m]=ym(i),time=new Date(epoch+i*duration).toISOString().replace('T',' ').replace('.000Z',' UTC');$('v11PxStartSaved').textContent=`Saved commencement: Year ${y}, Month ${m} · ${time}`}
 function preview(){let idx;const mode=selected();$('v11PxFields').hidden=mode!=='custom';if(mode==='founding')idx=found;else if(mode==='current')idx=Math.max(found,Math.floor((Date.now()-epoch)/duration));else{const y=Number($('v11PxPersonalYear').value),m=Number(options.value);if(!Number.isSafeInteger(y)||y<2||y>9999||!Number.isInteger(m)||m<1||m>18){$('v11PxStartPreview').textContent='Select a valid year and month.';return}idx=index(y,m)}const [y,m]=ym(idx);$('v11PxStartPreview').textContent=idx<found?'Choose Year 2, Month 15 or later.':`Year ${y} · Month ${m} — ${new Date(epoch+idx*duration).toISOString().slice(0,10)} UTC`;}
 const [y,m]=ym(saved());$('v11PxPersonalYear').value=y;options.value=m;radios.find(r=>r.value==='custom').checked=true;
 radios.forEach(r=>r.addEventListener('change',preview));$('v11PxPersonalYear').addEventListener('input',preview);options.addEventListener('change',preview);
 $('v11PxSavePersonal').addEventListener('click',()=>{const mode=selected();$('v11StartMode').value=mode;if(mode==='custom'){$('v11StartYear').value=$('v11PxPersonalYear').value;$('v11StartMonth').value=options.value}else $('v11StartMode').dispatchEvent(new Event('change'));$('v11SaveJourney').click();const result=$('v11StartInfo').textContent||'';if(result.startsWith('Personal start:'))showSaved();else $('v11PxStartSaved').textContent=result||'Unable to save the selected commencement.';});
 document.addEventListener('visibilitychange',()=>{if(!document.hidden){preview();showSaved()}});preview();showSaved();
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',initialize);else initialize();
})();
