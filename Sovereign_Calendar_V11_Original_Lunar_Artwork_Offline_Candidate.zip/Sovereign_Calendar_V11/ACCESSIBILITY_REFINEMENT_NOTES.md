# V11 Accessibility refinement — candidate

## Implemented
- Keyboard-visible skip link to the active view.
- Arrow, Home, End keyboard focus navigation within the five-tab dock.
- `aria-current=page` on active dock item; polite screen change announcements.
- Accessible labels on legacy collapsible section summaries.
- Larger tap targets for buttons and primary controls without enlarging decorative icons.
- Strong focus-visible styles; reduced-motion and forced-colors support.
- Native font sizing for text inputs to avoid mobile focus zoom.

## Verification boundaries
Offline math, month navigation, backup, JS syntax, assets, and ZIP checked. Do not claim WCAG conformance. Android TalkBack, VoiceOver, browser zoom at 200%/400%, landscape, keyboard-only traversal of every research instrument, contrast and real touch hit-area measurements need user tests.

## Release
No changes to calendar math, Praxis, backup schemas, or artwork. No deployment.
