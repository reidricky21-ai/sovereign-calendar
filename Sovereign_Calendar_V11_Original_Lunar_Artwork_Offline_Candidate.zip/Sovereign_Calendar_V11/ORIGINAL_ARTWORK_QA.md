# Sovereign Calendar V11 — Original Artwork Packaging QA

## Fixed
- Restored all 10 user-supplied PNG originals named by the existing artwork manifest (no substitutes).
- Gallery downloads now link to each manifest `original` PNG, rather than WebP fallback.
- Added original PNGs to the service-worker offline precache and changed the cache key.
- Updated PWA display name to identify the original-art QA candidate.

## Verified
- 10/10 manifest originals, 10/10 displays, 10/10 thumbnails present.
- All 61 explicit precache paths present.
- All 22 JavaScript files passed `node --check`.
- `offline_test.js`, `calendar_navigation_test.js`, `backup_roundtrip_test.js` passed.
- No changes made to the Sovereign/Praxis time engines or local-storage data schemas.

## Open release acceptance
- Persistent-origin browser save/reload and full user-data backup/restore.
- Normal-origin artwork download and service-worker offline behavior.
- Android PWA update, old-cache removal, and existing-user-data preservation.
- Final visual comparison to approved mockups.

**This is an offline QA candidate, not a verified production release.**
