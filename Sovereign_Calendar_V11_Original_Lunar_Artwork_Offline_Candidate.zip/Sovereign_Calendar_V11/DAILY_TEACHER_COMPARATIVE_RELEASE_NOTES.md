# Daily Teacher Comparative Grammar — V11 candidate

Adds an optional Qe/Ne/Te scope picker and three-stage Recognition / Comparison / Clarification teaching for the live Sovereign-vs-Praxis pair. Includes bespoke prompts for selected pairs, source-neutral compositional prompts for remaining pairs, and optional exercises. It never scores, penalizes, or gates study.

Original 8-day Sovereign operator sequence, independent 8-stage Praxis and 29.53-day mathematical month untouched. Source sutras retained separately; all new comparative prose is labeled interpretive. Local mode preference only; backup integration for this new preference is not verified.

Offline cache version bumped; Android PWA installation upgrade and preservation of existing data still require device-level tests.
