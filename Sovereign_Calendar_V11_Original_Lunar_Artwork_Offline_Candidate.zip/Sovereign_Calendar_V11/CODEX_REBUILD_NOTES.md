# V11 Codex reconstruction — offline checkpoint

Illustrated Codex operator selection, source caveats and mode cards are now layered over the unchanged V9 lexicon and scope laboratory. The existing grammar controls and navigation remain intact.

The short operator definitions in the new cards are editorial orientation glosses. The historical source material stays authoritative where definitions differ. New illustrated operator assignments are thematic and must be reviewed against user artwork.

**Unverified**: mobile browser rendering, operator image mapping completeness, installed Android PWA, end-to-end legacy grammar interaction. Do not deploy yet.
