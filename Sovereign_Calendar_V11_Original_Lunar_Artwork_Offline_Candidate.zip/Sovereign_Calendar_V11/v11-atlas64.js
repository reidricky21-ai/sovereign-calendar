/* 64-pair interpretive index. Mathematical pairings are independent of interpretations. */
(()=>{'use strict';
const $=id=>document.getElementById(id);
const host=$('v11AlignmentAtlas');if(!host)return;
const sov=['Se','Me','Le','Da','Ye','Ha','Re','Ka'];
const praxis=['Se','Me','Ye','Da','Ka','Re','Le','Ha'];
const meaning={Se:'Essence',Me:'Identity',Le:'Truth',Da:'Structure',Ye:'Purpose',Ha:'Hiddenness',Re:'Resonance',Ka:'Force'};
const lessons={Se:'Preserve',Me:'Know',Ye:'Align',Da:'Establish',Ka:'Act',Re:'Receive',Le:'Truth',Ha:'Renew'};
const authored={
 'Se-Se':['Preserving Essence','Preservation begins by examining what is essential rather than assuming it.','What is essential here, and how do I know?'],
 'Me-Me':['Knowing Identity','Recognition becomes more reliable when identity is examined against evidence.','What remains consistent through change?'],
 'Le-Ye':['Alignment with Truth','Purpose becomes coherent when it responds to what is actually true, rather than demanding that reality conform to intention.','What evidence might require me to reconsider my approach?'],
 'Da-Da':['Establishing Structure','Structure can be examined by considering the foundations and relationships that sustain it.','Which foundations are necessary for this to endure?'],
 'Ye-Ka':['Acting with Purpose','Action can be compared with the purpose it is intended to express.','Do my actions actually express my intention?'],
 'Ha-Re':['Receiving the Hidden','Feedback can reveal aspects of an experience that were previously unrecognized.','What remains unseen, and what might help reveal it?'],
 'Re-Le':['Testing Truth through Feedback','A response can be examined for what it supports and what remains uncertain.','What does this feedback actually establish?'],
 'Ka-Ha':['Renewing through Sovereignty','Agency may support renewal without requiring the outcome to be forced.','What can I change without presuming control of every consequence?']
};
const section=document.createElement('section');section.className='v11-atlas64';section.id='v11Atlas64';section.setAttribute('aria-labelledby','v11Atlas64Title');
section.innerHTML='<h3 id="v11Atlas64Title">64-pair Alignment Atlas</h3><p>The full reference of eight continuous Sovereign operators against eight monthly Praxis teachings. Every pairing is mathematically possible. Eight carry authored interpretations; the remaining 56 remain open for study. Selecting a reference pair does not change the live calendar.</p><div class="v11-atlas64-tools"><label for="v11Atlas64S">Sovereign operator</label><select id="v11Atlas64S"></select><label for="v11Atlas64P">Praxis teaching</label><select id="v11Atlas64P"></select><button id="v11Atlas64Current" type="button">Show current pairing</button></div><div id="v11Atlas64Grid" class="v11-atlas64-grid" aria-label="All 64 operator pairings"></div><article id="v11Atlas64Detail" class="v11-atlas64-detail" aria-live="polite"></article>';
host.append(section);
const a=$('v11Atlas64S'),b=$('v11Atlas64P'),grid=$('v11Atlas64Grid'),detail=$('v11Atlas64Detail');
for(const [select,arr,prefix] of [[a,sov,'Sovereign'],[b,praxis,'Praxis']])for(const op of arr){const option=document.createElement('option');option.value=op;option.textContent=op+' — '+(prefix==='Sovereign'?meaning[op]:lessons[op]);select.append(option)}
let selected='Se-Se';
const questions={
 'Se-Se':'What makes this essence essential, and is its defining nature preserved?',
 'Me-Me':'How does the identity demonstrated by habits compare with the ego’s self-representation?',
 'Le-Le':'How does the perception or belief compare with what is actually true?',
 'Da-Da':'Do existing structures correspond with the organizing principles they claim to sustain?',
 'Ye-Ye':'Does the present direction correspond with the purpose originally intended?',
 'Ka-Ka':'Does exercising force preserve the capacity for sovereignty, or create dependence upon control?',
 'Ha-Ha':'What remains latent, and what does continued concealment mean in context?',
 'Re-Re':'Is recurring resonance a faithful reflection, or familiarity reinforced through repetition?',
 'Se-Me':'How does essence become manifest through identity?',
 'Me-Se':'How does manifested identity correspond with its originating essence?',
 'Se-Re':'How does essence become perceptible through resonance and reflection?',
 'Re-Se':'Does what resonates faithfully reflect essential nature?',
 'Re-Le':'Does the interpretation of resonance correspond with Truth?',
 'Le-Re':'How is what is true made recognizable through reflection and resonance?',
 'Ka-Me':'Is force maintaining a constructed identity, or supporting its honest development?',
 'Me-Ka':'How does manifested identity influence how force is exercised?',
 'Da-Le':'Does the organization correspond with what is true?',
 'Le-Da':'How is Truth represented or obscured through structure?',
 'Ha-Re':'How does hidden potential become perceptible through resonance?',
 'Re-Ha':'What does a resonant response disclose, and what remains concealed?',
 'Ha-Ye':'How might concealed purpose become directional?',
 'Ye-Ha':'What remains unknown about the purpose being pursued?',
 'Ka-Ye':'Does applied force serve its intended purpose?',
 'Ye-Ka':'What action would express the intended purpose?'
};
const modes={Qe:['Outward','Observe the external situation and compare your perception with available evidence.'],Ne:['Inward','Examine the inward experience, self-understanding, motives and learned patterns.'],Te:['Invariant','Keep the reference independent of preference or self-image; no conclusion is automatic.']};
let mode='Qe';
const modeBar=document.createElement('div');modeBar.className='v11-atlas64-modebar';
const modeLabel=document.createElement('label');modeLabel.htmlFor='v11Atlas64Mode';modeLabel.textContent='Comparative mode';
const modeSelect=document.createElement('select');modeSelect.id='v11Atlas64Mode';
for(const [value,label] of [['Qe','Qe — Outward'],['Ne','Ne — Inward'],['Te','Te — Invariant']]){const opt=document.createElement('option');opt.value=value;opt.textContent=label;modeSelect.append(opt)}
const note=document.createElement('p');note.className='small';note.textContent='Exploratory comparative grammar: first operator = referent, second = comparison domain. The calendar pairs Sovereign operator and Praxis teaching; these are different systems and their correspondence does not itself certify an Akinraic translation.';
modeBar.append(modeLabel,modeSelect,note);detail.before(modeBar);
modeSelect.addEventListener('change',()=>{mode=modeSelect.value;choose(a.value,b.value)});

for(const s of sov)for(const p of praxis){const key=s+'-'+p;const btn=document.createElement('button');btn.type='button';btn.className='v11-atlas64-cell';btn.dataset.pair=key;btn.setAttribute('aria-label',`${s} Sovereign and ${p} Praxis, ${authored[key]?'authored interpretation':'unresolved interpretation'}`);btn.textContent=key;if(authored[key])btn.classList.add('authored');btn.addEventListener('click',()=>choose(s,p));grid.append(btn)}
function choose(s,p){if(!sov.includes(s)||!praxis.includes(p))return;selected=s+'-'+p;a.value=s;b.value=p;const d=authored[selected];detail.replaceChildren();
const h=document.createElement('h4');h.textContent=selected+' — '+(d?d[0]:'Interpretation unresolved');
const note=document.createElement('p');note.textContent='Sovereign: '+meaning[s]+' ('+s+'). Praxis: '+lessons[p]+' ('+p+').';
const body=document.createElement('p');body.textContent=d?d[1]:'This pair is mathematically defined, but a specific philosophical interpretation has not been approved. No relationship, consequence, or prediction is inferred from the combination alone.';
const inquiry=document.createElement('p');inquiry.textContent=d?'Reflection: '+d[2]:`Open inquiry: What, if anything, can be responsibly said about ${meaning[s]} in relation to the practice of ${lessons[p]}?`;
const status=document.createElement('small');status.textContent=d?'AUTHORED · Philosophical reflection, not empirical prediction or certified translation':'UNRESOLVED · Mathematical pairing only';
detail.append(h,note,body,inquiry,status);
const comp=document.createElement('section');comp.className='v11-comparative-note';
const compHead=document.createElement('h5');compHead.textContent=`${mode}{${selected.replace('-', '–')}} · ${modes[mode][0]} comparison`;
const roles=document.createElement('p');roles.textContent=`Referent: ${meaning[s]} (${s}). Comparison: ${meaning[p]} (${p}).`;
const question=document.createElement('p');question.textContent='Working inquiry: '+(questions[selected]||`How does ${meaning[s].toLowerCase()} relate to ${meaning[p].toLowerCase()} in this situation?`);
const scope=document.createElement('p');scope.textContent='Mode: '+modes[mode][1];
const caveat=document.createElement('small');caveat.textContent='PROPOSED INTERPRETATION · Not an approved source translation, empirical finding, or spiritual judgment.';
comp.append(compHead,roles,question,scope,caveat);detail.append(comp);
for(const btn of grid.children){const active=btn.dataset.pair===selected;btn.classList.toggle('selected',active);btn.setAttribute('aria-pressed',String(active))}}
a.addEventListener('change',()=>choose(a.value,b.value));b.addEventListener('change',()=>choose(a.value,b.value));
$('v11Atlas64Current').addEventListener('click',()=>{const x=window.SovereignPraxisMonth?.at(Date.now());if(x?.active)choose(x.s,x.p);else{detail.textContent='Praxis has not begun for this moment.'}});
window.addEventListener('v11:alignment-select',e=>{const t=e.detail?.timestamp;if(!Number.isFinite(t))return;const x=window.SovereignPraxisMonth?.at(t);if(x?.active)choose(x.s,x.p)});
const initial=window.SovereignPraxisMonth?.at(Date.now());if(initial?.active)choose(initial.s,initial.p);else choose('Se','Se');
window.SovereignAlignment64={operators:sov.slice(),praxis:praxis.slice(),authored:Object.keys(authored),select:choose};
})();
