# V11 compact visual shell

The shared top header is reduced to a manuscript title, a research menu button and a Settings icon. The old event controls remain inside Settings; the full instrument menu remains accessible from the menu icon. The five primary bottom tabs are unchanged. The Sovereign and Praxis engines, lesson sources and existing app data schema are unchanged.

This is an offline layout checkpoint, not an Android-validated release. Browser screenshots, popup focus handling, real localStorage persistence, and installation updates still need acceptance tests.
