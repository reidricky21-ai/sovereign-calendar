# V11 Personal Praxis Chamber — Offline checkpoint

## Implemented
- Dedicated illustration-led screen in Praxis > My Journey, matching the reference's gold/obsidian visual direction.
- Start modes: current mathematical month, canonical founding month, and custom Sovereign year/month.
- Visible computed commencement date and saved commencement confirmation.
- Uses the existing `v11StartMode`, `v11StartYear`, `v11StartMonth`, and `v11SaveJourney` code as the *only* storage writer; canonical calendar and backup schema remain unchanged.
- Original source artwork `artwork/ha-continuity.webp`; no substitute original-resolution export is claimed.
- Existing journal and past reflections are unchanged.

## Checks run
- JavaScript syntax, 234 unique UI IDs, offline asset references, and release gate passed.
- Existing mathematical calendar tests and five-category backup/restore sample round trip passed.
- Actual 360/390px screenshot comparison, click-through in a real browser origin, and Android installed PWA behavior not verified. Do not deploy to production yet.

## Known limits
- The existing core module still governs personal commencement and labels this branch as a Praxis Reference Preview. This is not a stable release.
- Calendar arithmetic and authoritative UTC month boundaries must never be changed from this UI.
