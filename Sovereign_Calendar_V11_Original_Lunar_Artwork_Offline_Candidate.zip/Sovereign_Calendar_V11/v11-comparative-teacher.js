(()=>{'use strict';
const $=id=>document.getElementById(id);
const domains={Se:'Essence',Me:'Identity',Le:'Truth',Da:'Structure',Ye:'Purpose',Ka:'Force / sovereignty',Ha:'Hiddenness',Re:'Resonance / reflection'};
const custom={
 'Ka-Ka':['Does this exercise of force protect sovereignty, or preserve dependence upon control?','Notice a situation involving control; identify what is being protected.'],
 'Me-Me':['How does demonstrated identity compare with the identity constructed through experience and aspiration?','Consider one self-description alongside your recurring actions.'],
 'Le-Le':['Does the interpretation correspond with what is true, independently of certainty?','Distinguish an observation, its interpretation and what remains unknown.'],
 'Re-Re':['Does an experienced reflection correspond with its source, or merely repeat what is familiar?','Notice a recurring response without assuming that familiarity confirms Truth.'],
 'Re-Se':['Is what resonates a reflection of essential nature, or of acquired identity and habit?','Explore one attraction without assuming you know its cause.'],
 'Se-Re':['How does essential nature become recognizable through resonance and reflection?','Observe an expression of identity without assuming it exhausts essence.'],
 'Ha-Re':['How does what remains hidden become perceptible through its effects?','Name something you notice and distinguish it from what remains concealed.'],
 'Ha-Ha':['What remains latent, and what would be premature to conclude?','Make room for uncertainty without treating latency as failure.'],
 'Me-Le':['What is actually supported by the evidence about manifested identity?','Compare a self-belief with lived examples.'],
 'Le-Me':['How is what is true about identity perceived or represented?','Examine whether a label captures the whole evidence.'],
 'Se-Me':['How might essence become manifested through identity?','Consider a quality demonstrated through repeated behavior.'],
 'Me-Se':['What in manifested identity can legitimately be inferred about essence?','Distinguish observed habits from claims about essential nature.'],
 'Da-Me':['How do surroundings and habitual structures shape manifested identity?','Notice a routine and a condition supporting it.'],
 'Me-Da':['How does established identity sustain or change structure?','Identify a pattern you maintain through repeated action.'],
 'Ye-Ka':['What action would effectively express the stated purpose?','Choose a small optional action linked to an intention.'],
 'Ka-Ye':['Does the applied force actually serve the intended purpose?','Contrast the intention behind an action with its observed effect.'],
 'Ha-Ye':['How might concealed potential become a direction of purpose?','Consider one unexplored possibility without assuming an ability.'],
 'Ha-Da':['What conditions could let hidden potential become investigable?','Identify an opportunity for a modest experiment.']
};
const modeText={
 Qe:{rec:'Observe the external situation before explaining it.',clar:'Separate what occurred from the story inferred about it.',prefix:'In the outward situation, '},
 Ne:{rec:'Notice the inward experience, belief or motivation.',clar:'Distinguish an authentic experience from an unverified interpretation of its source.',prefix:'Within personal experience, '},
 Te:{rec:'Identify what remains the reference regardless of preference or circumstance.',clar:'Keep the referent independent of the conclusion; the invariant mode does not certify an answer.',prefix:'Under the invariant reference, '}
};
function readMode(){try{const v=localStorage.getItem('sov_v11_comparative_teacher_mode');return modeText[v]?v:'Ne'}catch{return 'Ne'}}
function saveMode(v){try{localStorage.setItem('sov_v11_comparative_teacher_mode',v)}catch{}}
function render(){const x=window.SovereignPraxisMonth?.at(Date.now());if(!x?.active || !domains[x.s] || !domains[x.p])return;
 const mode=$('v11CtMode')?.value||'Ne', a=x.s,b=x.p,key=a+'-'+b, d=modeText[mode];if(!d)return;
 const line=custom[key] || [`How does ${domains[a].toLowerCase()} relate to ${domains[b].toLowerCase()} in this situation?`,'Choose one observation, then state what remains uncertain.'];
 $('v11CtPair').textContent=mode+'{'+a+'–'+b+'} · '+domains[a]+' / '+domains[b];
 $('v11CtParse').textContent='Referent: '+a+' ('+domains[a]+') · Comparison: '+b+' ('+domains[b]+')';
 $('v11CtRecognize').textContent=d.rec;
 $('v11CtQuestion').textContent=d.prefix+line[0].charAt(0).toLowerCase()+line[0].slice(1);
 $('v11CtClarify').textContent=d.clar;
 $('v11CtPractice').textContent='Optional practice: '+line[1];
}
function init(){const sel=$('v11CtMode');if(!sel)return;sel.value=readMode();sel.addEventListener('change',()=>{saveMode(sel.value);render()});render();document.addEventListener('visibilitychange',()=>{if(!document.hidden)render()});setInterval(()=>{if(!document.hidden)render()},60000)}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
