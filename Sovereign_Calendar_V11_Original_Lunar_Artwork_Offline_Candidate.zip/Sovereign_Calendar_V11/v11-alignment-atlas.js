/* V11 illustrated alignment reader; the mathematical engine remains authoritative. */
(()=>{'use strict';
const E=window.SovereignEngine, $=id=>document.getElementById(id);if(!E||!$('v11AlignmentAtlas'))return;
const names={Se:'Essence',Me:'Identity',Le:'Truth',Da:'Structure',Ye:'Purpose',Ha:'Hiddenness',Re:'Resonance',Ka:'Force'};
const principles={Se:'Preserve',Me:'Know',Ye:'Align',Da:'Establish',Ka:'Act',Re:'Receive',Le:'Truth',Ha:'Renew'};
const praxis=['Se','Me','Ye','Da','Ka','Re','Le','Ha'];
const approved={
'Se-Se':['Preserving Essence','Preservation begins by examining what is essential rather than assuming it.','What is essential here, and how do I know?'],
'Me-Me':['Knowing Identity','Recognition becomes more reliable when identity is examined against evidence.','What remains consistent through change?'],
'Le-Ye':['Alignment with Truth','Purpose becomes coherent when it responds to what is actually true, rather than demanding that reality conform to intention.','What evidence might require me to reconsider my approach?'],
'Da-Da':['Establishing Structure','Structure can be examined by considering the foundations and relationships that sustain it.','Which foundations are necessary for this to endure?'],
'Ye-Ka':['Acting with Purpose','Action can be compared with the purpose it is intended to express.','Do my actions actually express my intention?'],
'Ha-Re':['Receiving the Hidden','Feedback can reveal aspects of an experience that were previously unrecognized.','What remains unseen, and what might help reveal it?'],
'Re-Le':['Testing Truth through Feedback','A response can be examined for what it supports and what remains uncertain.','What does this feedback actually establish?'],
'Ka-Ha':['Renewing through Sovereignty','Agency may support renewal without requiring the outcome to be forced.','What can I change without presuming control of every consequence?']};
function show(t,day){const m=E.calculate(new Date(t)).globalMonth;const s=E.calculate(new Date(t)).op[0];const actual=window.SovereignPraxisMonth?.at(t);const p=actual?.p||praxis[(day-1)%8];const active=Boolean(actual?.active);
 $('v11AlignS').textContent=s;$('v11AlignSName').textContent=names[s];$('v11AlignP').textContent=active?p:'—';$('v11AlignPName').textContent=active?principles[p]:'Not founded';
 const a=active?approved[s+'-'+p]:null;
 $('v11AlignTitle').textContent=a?a[0]:active?'Interpretation unresolved':'Before Praxis founding';
 $('v11AlignMeaning').textContent=a?a[1]:active?'This relationship has not yet received an approved authored interpretation. The pairing itself remains mathematically defined.':'The founding Praxis sequence does not apply to this earlier month.';
 $('v11AlignQuestion').textContent=a?a[2]:'What is established, and what remains to be examined?';
 $('v11AlignStatus').textContent=a?'Authored philosophical interpretation · Not a certified translation or empirical prediction':'UNRESOLVED interpretation · Mathematical pairing only';
}
window.addEventListener('v11:alignment-select',e=>{const d=e.detail; if(d)show(d.timestamp,d.day)});
$('v11AlignDetails')?.addEventListener('click',()=>$('v10MonthControls')?.scrollIntoView({behavior:'smooth',block:'start'}));
const current=E.calculate(new Date());const start=E.EPOCH+current.globalMonth*E.MONTH;show(start,1);
})();
