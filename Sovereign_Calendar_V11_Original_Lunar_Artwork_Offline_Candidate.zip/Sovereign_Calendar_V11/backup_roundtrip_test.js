const fs=require('fs'),vm=require('vm'),assert=require('assert');
const storage=new Map();const handlers={};let backup,restored=false;let blobText='';
const elements={};const el=id=>elements[id]??=( {hidden:true,value:'',addEventListener:(event,fn)=>handlers[id+':'+event]=fn,textContent:'',click(){},remove(){}} );
class FakeBlob {constructor(parts){blobText=parts.join('')} }
const doc={getElementById:el,createElement:()=>({href:'',download:'',click(){},remove(){}}),body:{appendChild(){}}};
const ctx={document:doc,localStorage:{getItem:k=>storage.has(k)?storage.get(k):null,setItem:(k,v)=>storage.set(k,v)},Blob:FakeBlob,URL:{createObjectURL:()=> 'blob:test',revokeObjectURL(){}},Date,JSON,Math,Number,Array,Object,String,Promise,setTimeout:()=>0,confirm:()=>true,location:{reload(){restored=true}},navigator:{},window:{},console};
vm.runInNewContext(fs.readFileSync('v7-release.js','utf8'),ctx,{timeout:2000});
const source={sovereign_events_v1:JSON.stringify([{date:'2026-10-17',title:'Test event'}]),sovereign_praxis_v2:JSON.stringify([{date:'2026-10-17',type:'Reflection',note:'Test'}]),'sov-v11-gallery-favorites':JSON.stringify(['ha-continuity']),'sov-v11-alignment-reflections':JSON.stringify({'Se-Se':'Essence'}),'sov-v11-personal-praxis-start':'32'};
for(const [k,v] of Object.entries(source))storage.set(k,v);
handlers['backupAllBtn:click']();assert(blobText,'Backup JSON not produced');backup=JSON.parse(blobText);assert.equal(backup.format,'sovereign-calendar-full-backup');for(const k of Object.keys(source)) assert.equal(backup.data[k],source[k]);
for(const k of Object.keys(source))storage.delete(k);
handlers['restoreAllInput:change']({target:{files:[{size:blobText.length, text:async()=>blobText}],value:'test'}});
setTimeout(()=>{for(const [k,v] of Object.entries(source))assert.equal(storage.get(k),v,'round-trip '+k);assert(restored,'Reload expected');console.log('PASS: five-category full backup/restore round-trip, schema and version '+backup.appVersion);},50);
